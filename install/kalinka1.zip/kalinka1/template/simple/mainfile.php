<?php  if(!defined('BUGIT')) exit ('Ошибка соединения');
/**@package CMS-KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2017 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.0
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
 ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
     <meta http-equiv="x-ua-compatible" content="ie=edge" />
 <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="template/simple/style.css" />
<meta name="description" content="<?php if(isset($annotat) && isset($annotat[$id])) echo $annotat[$id];   ?>" />
<meta name="keywords" content="<?php if(isset($keywords) && isset($keywords[$id])) echo $keywords[$id];?>" />
<link rel="icon" href="favicon.ico" type="image/x -icon" />       
<title><?php if(isset($titlear) && isset($titlear[$id]))  echo $titlear[$id]; ?></title>
</head>
<body> 
<!--Левый базовый блок -->
   <div id="baseleftwrapper"><!--baseleftwrapper -->

  <!--Логотип -->
    <div id="logotype"><!-- logotype-->
       <img src="images/logotype.png" alt="LOGOTYPE"/>
    </div><!--end logotype-->

  <!--Домен -->
    <header><!--header-->
        <h2><?php if(isset($heading)) echo $heading ?></h2>
    </header><!--end header-->

<!--Очистка плавающих элементов -->
    <div class="clear"></div> <!--clear-->

 
  <!--Общее меню узлов  При необходимости можно закомментировать-->
     <menu>
         <li> <a href="mysitemap.html">Карта сайта</a></li>
         <li> <a href="index.php">Блог</a></li>
<?php
               if(isset($arrforblock))
                 foreach($arrforblock as $key=>$value) {
                    if(file_exists($key)) {
         ?>
            <li><a href="index.php?unit=<?php echo $key ?>" title="<?php echo $value; ?>"><?php echo $value; ?> </a></li> <?php
              }
 } ?>
     </menu>  
   <!--Наименование текущей категории или ничего -->

      <p class="capitel">
        <?php if(isset($numberpart) && $idpart[$id]!==0) echo $menupart[$numberpart]; ?>
      </p>


    <main>
      <!--Статья -->    
      <article><!--content-->
        <?php //Область контента
if(isset($unit)) {
              if(isset($pos[17])) {
                  $viewvideo=$unit.$id;
              if(file_exists("modul/$pos[17]/$unit/")) {
   
                     if(isset($pos) && isset($pos[17]))  {
                         $flname="modul/$pos[17]/def.php";
                         if(file_exists($flname))
                           include_once $flname;
                          }                       
                 }                    clearstatcache();
               } 

   if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar) && isset($titlear[$id]) && isset($contentar[$id]) && isset($authorar[$id]) && isset($datar[$id])) {
     echo "<h1> $titlear[$id]</h1>";
      echo  $contentar[$id];
      echo "<address>";echo $authorar[$id]."</address>";
      echo "<time>".$datar[$id]."</time>";
         }
     switch($unit) {
                    case 'payware':
                     //Модуль Купить  
                    break;

                    case 'shop':
                     //Модуль Купить                       
                    break;

                    default:
                     //Модуль Скачать
                       if(isset($id) && $id>1) {
                                   if(isset($pos[19])) {
           $flname="modul/$pos[19]/def.php";
           if(file_exists($flname))
             if(file_get_contents($flname))
             include_once $flname;
                             }  
                         }       
                    break;
   
        }
   }

         if(isset($pos[18])) {
           $flname="modul/$pos[18]/def.php";
           if(file_exists($flname))
             if(file_get_contents($flname))
             include_once $flname;
            }

         if(isset($pos[12])) {
           $flname="modul/$pos[12]/def.php";
           if(file_exists($flname))
             if(file_get_contents($flname))
             include_once $flname;
            }

 ?>
      </article><!--end content-->
 
      <!--Блок бокового меню -->
      <aside><!--menu-->

       <!--Главное меню сайта -->
       <nav>
         <?php
//Боковое меню
if(file_exists("variables/menusd.php")) include_once "menu/$menusd/menuside.php";
else include_once "menu/menusimple/menuside.php";
?><!-- end menu-->
       </nav>
      </aside><!--end menu-->
<!--Очистка плавающих элементов -->
    <div class="clear"></div> <!--clear-->
    </main>
 
   </div><!--end baseleftwrapper --> 

   
   <!--Правый базовый блок --> 
   <div id="baserightwrapper"><!--baserightwrapper -->
<?php if(!isset($_SESSION['nickname'])) { ?>
    <!--<a href="#formlog">Форма входа</a>-->
    <section><!--modul Форма входа, Позиция 6-->
         <?php if(isset($pos[6])) {
                 $flname="modul/$pos[6]/def.php"; 
                  if(file_exists($flname)) 
                    include_once $flname;
            } ?>
      </section><!--end modul1--><br>
<?php }
       else { ?>
<p class="capitel">Добро по&shy;жа&shy;ло&shy;вать, <i><?php echo $_SESSION['nickname']; ?>!</i></p>
<p><a class="capitel" href='exit.php'>Выйти</a></p>
 <?php  } ?>  
    <!--Встраиваемый модуль--> 
     <br> <section><!--modul 1, Позиция 2-->
         <?php if(isset($pos[2])) {
                 $flname="modul/$pos[2]/def.php"; 
                  if(file_exists($flname)) 
                    include_once $flname;
            } ?>
      </section><!--end modul1-->  
    
     <!--Встраиваемый модуль --> 
     <figure><!--modul 2, Позиция 1, 3-->
       <?php 
         if(isset($unit)) { 
               switch($unit){
                    case 'shop':
           if(file_exists("shop/regim.php")) {
               $flname="shop/regim.php";
             if(file_exists($flname))
             if(file_get_contents($flname)) 
                include_once $flname;
                      }
                    break;

                    case 'freeware':
          if(isset($pos) && isset($pos[1])) {
            $flname="modul/$pos[1]/def.php";
             if(file_exists($flname))
             if(file_get_contents($flname)) 
                 include_once $flname;
                     }
                   break;

                     case 'book':
                       if(isset($pos[3])) {
                         $flname="modul/$pos[3]/def.php";
                        if(file_exists($flname))
                        if(file_get_contents($flname)) 
                        include_once $flname;
                         }
                       break;
        }
   }
?> 
    </figure><!--end modul 2-->

     <br>

    <!--Встраиваемый модуль --> 
      <figure><!--modul 3, Позиция 4--> 
         <?php
           if(isset($unit)) {
               if(isset($pos[4])) {
                 $flname="modul/$pos[4]/def.php";
                   if(file_exists($flname))
                     if(file_get_contents($flname)) 
                     include_once $flname;
      }
  }
?>     
      </figure><!--end modul3-->
      
      <br>

    <!--Встраиваемый модуль --> 
      <figure><!--modul 4, Позиция 5--> 
         <?php
           if(isset($unit)) {
               if(isset($pos[5])) {
                 $flname="modul/$pos[5]/def.php";
                   if(file_exists($flname))
                     if(file_get_contents($flname)) 
                     include_once $flname;
      }
  }
?>                
      </figure><!--end modul4-->
     

   </div><!--end baserightwrapper --> 

<!--Очистка плавающих элементов -->
   <div class="clear"></div> <!--clear-->

   <!--Подвал -->
   <footer>
     <address>Автор CMS KALINKA  Copyright © 2013 - 2017 Родионова Галина Евгеньевна. Все права защищены.
    </address>
<?php 
//Обратная связь
if(isset($pos[16])) {
    $flname="modul/$pos[16]/def.php";
        if(file_exists("modul/$pos[16]/def.php")) 
          echo "<a href='modul/$pos[16]/def.php'>Обратная связь</a>"; 
 }

if(isset($menutit)) 
    foreach($menutit as $keycm=>$valcm) { ?>
     &nbsp;&nbsp;&nbsp;<a href="common/commonrules.php?page=common&amp;id=<?php echo $keycm ?>" rel="nofollow"><?php echo $valcm ?></a>
<?php
}
 ?>
   </footer>
       <p class="navdown" id="js-OnBottom">↓</p>
       <p class="navup" id="js-OnTop">↑</p>
<?php
//Кнопка Вверх-вниз

if(file_exists("lib/jquery/jquery-3.1.1.min.js")) {
echo '<script type="text/javascript" src="lib/jquery/jquery-3.1.1.min.js"></script>';		
echo "<noscript> <p class='p1'>Включите, пожалуйста, в Вашем Web-браузере поддержку JavaScript, если хотите что-либо скачать или прокомментировать на нашем сайте</p> </noscript>";}
 ?>
<script type="text/javascript" src="lib/beforemain.php"></script>
</body> </html>	

