<?php if(!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
include_once "variables/variac.php";
$mysqli=new mysqli(base64_decode($server),base64_decode($username),base64_decode($parol),base64_decode($datbas));
/* проверка соединения */
if (mysqli_connect_errno()) {printf("Соединение не установлено: %s\n", mysqli_connect_error());exit();
}
?>
