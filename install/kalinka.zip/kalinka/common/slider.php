<?php if(!defined ('BUDEMGITJ')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Формируем массив
if(isset($unit)) { 
$imageforslider=array();$dr="images/$unit/$id";$skip = array('.', '..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $imageforslider[]=$shmod;
} $countimage=count($imageforslider);if(isset($countimage) && $countimage>1) {	
?><div id="slider">
<div class="sliderBox"><a href="#" class="prevBtn">◄ </a>
        <a href="#" class="nextBtn">► </a>
        <div class="SimSlider"><?php if(isset($imageforslider)) {
foreach($imageforslider as $key=>$val) { ?>
                <div class="slide">                     
<img class="sliderimg" src="images/<?php echo $unit ?>/<?php echo $id ?>/<?php echo $key+1 ?>.png" alt="<?php echo $titlear[$id] ?>" />
                </div><?php } if(isset($annotat[$id])) echo "<p>$annotat[$id]</p>"; } ?>                
        </div>
</div></div><?php } else {if(file_exists("images/$unit/$id/1.png")) { ?><div id="slider">
<div class="sliderBox"><div class="SimSlider"><img class="sliderimg" src="images/<?php echo $unit ?>/<?php echo $id ?>/1.png" alt="<?php echo $titlear[$id]; ?>" /></div></div></div> <?php } }
}
?>
