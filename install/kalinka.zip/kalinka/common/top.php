<?php header("Content-Type: text/html; charset=utf-8");if(!defined ('BUGIT')) exit ('Ошибка соединения');
/**@package  KALINKA  @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Информация - узлы
$arrforblock=array("book"=>"О программе Компас 3D LT","book1"=>"Блог1","freeware"=>"Скачивания","shop"=>"Магазин","payware"=>"Платные продукты",);
//Если узлы отсутствуют - подключаем узел Блог
if(isset($_GET['unit'])) $unit=addslashes(strip_tags(trim($_GET['unit'])));
else {$unit="book";} 
if(isset($_GET['id'])) $id=intval($_GET['id']); else $id=1;
//Перенаправление на скачивание свободных продуктов
if(isset($_GET['freeload'])) $freeload=addslashes(strip_tags(trim($_GET['freeload'])));
if(isset($unit) && isset($_GET[$unit])) $kat=addslashes(strip_tags(trim($_GET[$unit])));//Случай отображения ряда страниц на одной вкладке
if(isset($_POST['regsub'])) $regsub=htmlspecialchars(trim($_POST['regsub']));
if(isset($regsub)) //Регистрация
{if(file_exists("common/login.php")) include_once"common/login.php";}
if(file_exists("lib/library.php")) include_once "lib/library.php";
//Вызов массива модулей
if (file_exists("common/modulen.txt"))
{$ct="common/modulen.txt";
$fon=fopen($ct, "r");
$immod=unserialize(fread($fon, filesize($ct)));
if (!is_array ($immod)) {// если что-то прошло не так, инициализировать  массив
$immod=array("modcreg"=>array("pos"=>6,"russ"=>"Модуль входа",'dopcon'=>0),"mdObr"=>array("pos"=>0,"russ"=>"Обратная связь",'dopcon'=>16));
}
fflush($fon);fclose($fon);
}
//Определяем позицию модулей
if(isset($immod))
{foreach($immod as $key=>$val)
$posone[$key]=$immod[$key]['pos'];
$pos=array_flip($posone);
}
//Включение служебных файлов: текущее меню, текущий логотип, текущий шаблон
if(file_exists("variables/menusd.php")) include_once "variables/menusd.php";
if(file_exists("variables/variables.php")) include_once "variables/variables.php";
if(file_exists("variables/logotype.php")) include_once "variables/logotype.php";
if(file_exists("variables/vartempl.php")) 
{if(file_get_contents("variables/vartempl.php")) include_once "variables/vartempl.php";} else $osnova='simple';
if(file_exists("template/$osnova/newkey.php")) { include_once "template/$osnova/newkey.php";
if(isset($keytempl)) $fortemplate=explode(",",$keytempl); 
if(isset($fortemplate) && $fortemplate[0]==="plat")
{//888888888888888888888888888888888888888888 Для платных шаблонов проверка
if($fortemplate[1]!=="ac22f5e1e233b67b656b703942b5b43e77402fe2") {$filename="$"."osnova";
// Каталог, в который мы будем принимать файл:
if(!file_exists("variables/")) mkdir ("variables/");
if(!file_exists("variables/vartempl.php")) touch('variables/vartempl.php');
$fp = fopen( "variables/vartempl.php", "w+")or die ("Не удалось открыть файл");
fputs($fp, "<?php if(!defined('BUGIT'))
exit ('Ошибка соединения'); $filename='simple'; ?>");
fclose( $fp );}
} 
}
//Переменные имен таблиц БД
if(isset($unit) && $unit!=="freeload"&& $unit!=="comm") {if(file_exists("main$unit.php"))  {
$maintable=$unit;
$parttable="part".$unit;
$chaptertable="chapter".$unit;
}
//Проверка записей в таблице Статьи
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) {if($articfirst=$mysqli->query("SELECT id FROM $maintable"))  {$num=$articfirst->num_rows; if(isset($num) && $num>0) $idartic="YES";} else {$idartic="No";}if($articfirst) $articfirst->close();}

// проверка на наличие разделов********************
if($partfirst=$mysqli->query("SELECT id FROM $parttable"))  {$num=$partfirst->num_rows; if(isset($num) && $num>0) $idfirst="YES";} else {$idfirst="No";}if($partfirst) $partfirst->close();
//Проверка записей в таблице Главы************************
if($chaptfirst=$mysqli->query("SELECT id FROM $chaptertable"))  {$num=$chaptfirst->num_rows; if(isset($num) && $num>0) $idsnd="YES";} else {$idsnd="No";}if($chaptfirst) $chaptfirst->close();
}
if(isset($unit)) {
//Отображение заголовков, текстов
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) {if(isset($id)) {if($selarticle=$mysqli->prepare("SELECT title, content,author,dat,keywords,annotation,idpart FROM $maintable WHERE id=? ORDER BY list ")) {
$selarticle->bind_param('i',$id); 
$selarticle->execute(); 
$selarticle->bind_result($titleart,$contentart,$authorart,$datart,$keywordar,$annotar,$partar); 
while($selarticle->fetch()){
$titlear[$id]=$titleart;
$contentar[$id]=$contentart;
$authorar[$id]=$authorart;
$datar[$id]=$datart;
$keywords[$id]=$keywordar;
$annotat[$id]=$annotar;
$partr[$id]=$partar;
} if(isset($selarticle)) $selarticle->close();}}} 
//Отображение цен
if(isset($id)) if(isset($unit) && $unit==="payware") {if($selcost=$mysqli->prepare("SELECT cost FROM passortment WHERE id=?")){$selcost->bind_param('i',$id);$selcost->execute();$selcost->bind_result($costart);while($selcost->fetch()){ $thiscost[$id]=$costart;} if(isset($selcost)) $selcost->close(); }
}
if(isset($id)) if(isset($unit) && $unit==="shop") {if($selcost=$mysqli->prepare("SELECT cost FROM assortment WHERE id=?")){$selcost->bind_param('i',$id);$selcost->execute();$selcost->bind_result($costart);while($selcost->fetch()){ $thiscost[$id]=$costart;} if(isset($selcost)) $selcost->close(); }}
if(file_exists("basket/modValut/curs.txt"))   
{
$curs=file("basket/modValut/curs.txt"); $date=$curs[0];  
$dollar= $curs[1];  
$euro=$curs[2];if(isset($dollar) && isset($thiscost[$id])) $costDOLL=round($thiscost[$id]/$dollar,2); 
} 
//Все статьи выбока заголовков********************
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selmainmenu=$mysqli->prepare("SELECT id,title FROM $maintable ORDER BY list ")) {
$selmainmenu->execute(); 
$selmainmenu->bind_result($idmain,$titlemain); 
while($selmainmenu->fetch()){
$menutitun[$idmain]=$titlemain;
} if(isset($selmainmenu)) $selmainmenu->close();}
}
//статьи простых разделов выборка заголовков********************
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selsimplemenu=$mysqli->prepare("SELECT id,title FROM $maintable WHERE id>1 AND idpart>0 AND idchapter=0  ORDER BY list ")) {
$selsimplemenu->execute(); 
$selsimplemenu->bind_result($idsimple,$titlesimple); 
while($selsimplemenu->fetch()){
$menutit[$idsimple]=$titlesimple;
} if(isset($selsimplemenu)) $selsimplemenu->close();}
}
//Ключевые статьи выборка заголовков
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selkeymenu=$mysqli->prepare("SELECT id,title FROM $maintable WHERE idpart=0 AND idchapter=0  ORDER BY list ")) {
$selkeymenu->execute(); 
$selkeymenu->bind_result($idkey,$titlekey); 
while($selkeymenu->fetch()){
$menutitle[$idkey]=$titlekey;
} if(isset($selkeymenu)) $selkeymenu->close();}
}
//Выборка данных разделов*********************************
$mysqli->query("SET NAMES 'utf8'");
if(isset($idfirst) && $idfirst==="YES") {if($res=$mysqli->query("SELECT * FROM $parttable")) while($menupt=$res->fetch_assoc()){if(isset($menupt["id"])) $forcontent=$menupt["id"];$menupart[$forcontent]=$menupt["title"];}if(isset($res)) $res->close();if(isset($forcontent)) unset($forcontent);}
//Определяем номер раздела для статьи, входящей в раздел
if(isset($id) && isset($menutitle) && isset($menutitle[$id]) && isset($menupart)) {
if(array_search($menutitle[$id],$menupart)) $idpart=array_search($menutitle[$id],$menupart);
} else {if(isset($partr) && $partr!==0) $idpart=$partr[$id];}
//Если таковой номер раздела имеется выводим контент вложенных в раздел статей
if(isset($idpart) && $idpart!==0) {$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selmenupart=$mysqli->prepare("SELECT id,title,content,author,dat,keywords,annotation FROM $maintable WHERE id>1 AND idpart='$idpart' AND idchapter=0  ORDER BY list")) {
$selmenupart->execute(); 
$selmenupart->bind_result($idpt,$titlekeypt,$contentpt,$authorpt,$datpt,$keywordspt,$annotationpt); 
while($selmenupart->fetch()){
$menutitlepart[$idpt]=$titlekeypt;
} if(isset($selmenupart)) $selmenupart->close();}
}}
}
?>
