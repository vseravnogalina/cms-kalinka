<?php header("Content-Type: text/html; charset=utf-8");if(!defined ('BUGIT')) exit ('Ошибка соединения');
/**@package  KALINKA  @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Электронная почта покупателя
if(isset($_POST['eml'])) $eml=htmlspecialchars(strip_tags(trim($_POST['eml'])));
//Группа пользователя
if(isset($_POST['groupcostomer'])) $groupcostomer=intval($_POST['groupcostomer']);
//Имя 
if(isset($_POST['imvh'])) $imvh=htmlspecialchars(strip_tags(trim($_POST['imvh'])));
if(isset($_POST['ip'])) $ip=htmlspecialchars(strip_tags(trim($_POST['ip']))); $ip=str_replace(".","",$ip);
if(!preg_match("/^[a-zA-Zа-яА-Я0-9-_\.]{1,11}+(\s){1}+[a-zA-Zа-яА-Я-_\.]{0,14}+$/u", $imvh)) $err[] = "Имя не может содержать менее 2 символов";
if(isset($eml)) $emal= $mysqli->real_escape_string($eml);
if(isset($imvh)) $namekd= $mysqli->real_escape_string($imvh);
if(isset($regsub))
{$err=array();
if(!preg_match("/^[-\w.]+@([A-z0-9][-A-z0-9]+\.)+[A-z]{2,4}$/i", $eml)) $err[] = "Некорректный адрес электронной почты";
$oshibka=count($err);
//Если нет ошибок, 
if($oshibka === 0)
{$mysqli->query("SET NAMES 'utf8'");
if(isset($emal))
$res = $mysqli->query("SELECT * FROM costomers WHERE email='$emal'");
$row =$res->fetch_assoc();
//Если данные есть в базе, присваиваем сессию
if(isset($row['email']) && isset($row['name']))
{if($row['name']===$namekd && $row['email']===$emal) {if(isset($row['groupcost']) && $row['groupcost']>1)
{$emrk=$eml;$_SESSION['costomer']=$emrk;
$nmrk=$imvh;$_SESSION['nickname']=$nmrk;
if(isset($res)) $res->close();} else die("Администраторы здесь не регистрируются!");
}
else die("Такой пользователь уже существует!");
}
//Если данных нет, вносим их в базу и присваиваем сессию
else
{
$mysqli->query("SET NAMES 'utf8'");
$query ="INSERT INTO costomers(groupcost,email,name,ip) VALUES('".$groupcostomer."','".$emal."','".$namekd."','".$ip."')";
$result=$mysqli->query($query);
//Если данные успешно занесены в таблицу
if($result===TRUE)
{$emrk=$eml;$_SESSION['costomer']=$emrk;
$nmrk=$imvh;$_SESSION['nickname']=$nmrk;//И
//$result->close();
}
}
}	
//Если не так, то выводим ошибку
else
{ echo "<b>При регистрации произошли следующие ошибки:</b><br>";
foreach($err as $error) echo $error."<br>";
}
}
?>
