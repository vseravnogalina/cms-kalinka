<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(isset($id)) { 
if(file_exists("video/$id.mp4")) { ?>
<video width="400" height="300" controls="controls" poster="images/book/<?php echo $id ?>.png">
   <source src="video/<?php echo $id ?>.ogg" type='video/ogg; codecs="theora, vorbis"'>
   <source src="video/<?php echo $id ?>.mp4" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
   <!--<source src="1.webm" type='video/webm; codecs="vp8, vorbis"'>-->
   <a href="1.mp4">Скачайте видео</a>.
  </video>
<?php 
}
//Если статья относится к ключевым статьям idpart=0
if(isset($menutitle[$id])) 
{
//И отображаем контент ключевой страницы раздела
if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {echo "<h1> $titlear[$id]</h1>";echo "<div id='content'>".$contentar[$id];echo "<p>";echo $authorar[$id]."</p>";echo "<p>".$datar[$id]."</p></div>";}}
//Когда статья не является ключевой 
else {//Если статья - вложенная статья раздела
if(isset($id) && isset($menutitlepart[$id])) { 
if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {
echo "<h1>$titlear[$id]</h1><h4>Раздел $menupart[$idpart]</h4><div id='content'>";echo $contentar[$id]."<br>";echo "<p>".$authorar[$id]."</p>";echo "<p>".$datar[$id];?></p></div><?php 
if(isset($pos[18])) {$flname="modul/$pos[18]/def.php";
if(file_exists($flname))
if(file_get_contents($flname)) include_once $flname;}
} } //Если статья - простая  статья
/*else
{if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {echo "<h1>$titlear[$id]</h1><div id='content'>";echo $contentar[$id]."<br>";echo "<p>".$authorar[$id]."</p>";echo "<p>".$datar[$id]."</p></div>";}}*/
}
}



