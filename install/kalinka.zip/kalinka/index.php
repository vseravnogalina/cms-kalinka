<?php session_start();header("Content-Type: text/html; charset=utf-8");define ( 'BUGIT', true );
/**CMS KALINKA- свободный пакет программ: Вы можете *перераспространять ее и/или изменять ее на условиях Стандартной общественной *лицензии GNU GPL версия 3 в том виде, в каком лицензия *была опубликована Фондом свободного программного *обеспечения CMS KALINKAru распространяется в надежде, что она будет *полезной,но БЕЗ ВСЯКИХ ГАРАНТИЙ, даже без неявной гарантии ТОВАРНОГО ВИДА или ПРИГОДНОСТИ ДЛЯ ОПРЕДЕЛЕННЫХ ЦЕЛЕЙ.Подробнее см. в Стандартной общественной лицензии GNU
/**@package KALINKA @author Родионова Галина Евгеньевна https://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/	
//Формирование ссылки
//1. Переменная $unit существует, если существует имя файла вида main$unit Ссылка узла Книга-журнал-газета index.php?unit=book 
//условие:если есть запрос вида $_GET[unit]="имя узла" - определяет набор таблиц в БД, количество и необходимость дополнительных модулей на странице контента 
//Общий вид ссылки index.php?unit="имя узла"&id="id" 
if(file_exists("upr.php")) require_once "upr.php";
if(file_exists("common/top.php")) include_once "common/top.php";
if(isset($unit)) if(file_exists("$unit/top.php")) include_once "$unit/top.php";

?><!DOCTYPE html>
<html><head><meta charset="utf-8"/> <meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="<?php if(isset($annotat)) echo $annotat[$id];   ?>" />
<meta name="keywords" content="<?php if(isset($keywords)) echo $keywords[$id];?>" />
<link rel="icon" href="favicon.ico" type="image/x -icon" />       
<title><?php if(isset($titlear))  echo $titlear[$id]; ?></title>
<link rel="stylesheet" href="template/<?php echo $osnova ?>/style.css" />
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
</head><body> 
<?php
//Дальше вставлен шаблон
if (isset($osnova)) if(file_exists("template/$osnova/mainfile.php"))
include_once "template/$osnova/mainfile.php";
else include_once "template/simple/mainfile.php";
if (file_exists("lib/jquery/jquery-3.1.1.min.js"))   
 {echo '<script type="text/javascript" src="lib/jquery/jquery-3.1.1.min.js"></script>';		
echo "<noscript> <p class='p1'>Включите, пожалуйста, в Вашем Web-браузере поддержку JavaScript, если хотите что-либо скачать или прокомментировать на нашем сайте</p> </noscript>";}
if(file_exists("basket/basketpw")) {
?>
<script type="text/javascript" src="basket/basketpw/jvs.js"></script>
<?php } ?>
<script type="text/javascript" src="lib/javascript.js"></script>
<script>
        jQuery( function($){
                $('.sliderBox').SimSlider( {
                        next: '.nextBtn', // селектор стрелки вправо
                        prev: '.prevBtn', // селектор стрелки влево
                        item: '.SimSlider.slide', // селектор слайда
                        speed: 1200, // скорость прокрутки
                        delay: 5000 // задержка в мс
                } );
        } );
</script>
</body></html>
