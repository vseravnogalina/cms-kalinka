<?php header("Content-Type: text/html; charset=utf-8");if(!defined ('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA  @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(isset($menutitun)) //Во всех статьях
foreach($menutitun as $k=>$v) {if(isset($id) && $id===$k) { ?>
<p class="p4"><?php echo $v; ?></p><?php
if(isset($idpt)) {if(isset($menutitlepart)) { ?>
<div class="rightsecondline"> <?php  foreach($menutitlepart as $key=>$val) {
if($key!==$k) { ?>
<p class="p2"><a href="index.php?unit=<?php echo $unit ?>&amp;id=<?php echo $key;?>" title="<?php echo $val; ?>"><?php echo $val; ?></a></p>
<?php } } ?>
</div> <?php 
}}
}
else {if(isset($menutitle[$k])) {
//Ключевые статьи(имена разделов и отдельных статей вне разделов)
if(isset($menupart) && count($menupart>=1) && array_search($v,$menupart)==true) { ?>
<p class="p3"><a href="index.php?unit=<?php echo $unit ?>&amp;id=<?php echo $k; ?>" title="<?php echo $v;?>"><?php echo $v; ?></a></p><?php 
}
else { ?><p><a href="index.php?unit=<?php echo $unit ?>&amp;id=<?php echo $k; ?>" title="<?php echo $v;?>"><?php echo $v; ?></a></p><?php }
}}
}
?>
