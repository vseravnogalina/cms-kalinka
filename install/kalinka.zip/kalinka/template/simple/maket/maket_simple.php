<?php session_start();header("Content-Type: text/html; charset=utf-8");
define ( 'BUGIT', true );
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2018 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.0
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/	
?>
<!DOCTYPE html>
 <html lang="ru">
   <head>
     <meta charset="utf-8"/>
     <meta http-equiv="x-ua-compatible" content="ie=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
     <meta name="description" content="" />
     <meta name="keywords" content="" />
<link rel="icon" href="../../../favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="../style.css" />
     <title>Unatka</title>
   </head>

   <body>
<?php echo "<a href='$_SERVER[HTTP_REFERER]'>Вернуться</a>";?>
<!--Левый базовый блок -->
   <div id="basewrapper"><!--basewrapper 1-4, 1-,auto -->
     <div class="arrow">
       <p class="navdown" id="js-OnBottom">↓</p>
       <p class="navup" id="js-OnTop">↑</p>
     </div>

    <header>
  <!--Общее меню узлов  При необходимости можно закомментировать  1-4, 1-2,auto -->

      <nav id="top">
        <ul>
         <li>
             <a href="mysitemap.html">Карта сайта</a>
         </li>
         <li><a href="">Menu</a></li> 
         <li><a href="">Menu</a></li> 
         <li><a href="">Menu</a></li> 
        </ul>
      </nav><!--menu-->

      <div class="formlogin">
       <a id="linkancor" class="secondbutton js-secondbutton">Форма входа</a>
        <div class="forForm" hidden> <!--class="forForm"-->
          <a class="close js-close">Закрыть</a>
          <form  method="POST">
            <fieldset>
               <legend><mark><i>Форма входа</i></mark></legend>
               <input type="hidden" name="groupcostomer" value="4"/>
               <p><input type="text" name="nickname" value="" placeholder="Ваше имя:" required /></p>
               <p><input type="email" name="eml" value="" placeholder="E-mail:" required /></p>
               <p><input type="checkbox" name="agry" value="1" checked />Я согласен(на) на обработку моих персональных данных
              <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR'] ?>" >
              <p><input type="submit" name="enter"  class="button"  value="Войти!" /></p>
           </fieldset>
         </form> 
      </div><!--forForm--> 
    </div><!--formlogin-->
   </header>

   <div id="nav">

<!--Наименование текущей категории или ничего flex 1height:102px;-->
      <h3>Category</h3> 

<!--Домен flex 2(flex 1-2 вложенный для буквицы)-->
        <div class="conteiner">
          <div class="firstpart">U</div>
          <div class="secondpart">natka.ru</div>
        </div><!--end conteiner--> 
      <div class="clear"></div>

  </div><!--nav--> 

    <div class="conteinerarticle">      
      <!--Статья 1-2,3-4, auto-->    
      <article id="forarticle"><!--content-->
        <p><a class="arrowlast" href="">Смотреть видео</a></p>
        <h1>content</h1>
          <p>textТрансформация — это изменение вида элемента, к которым относятся следующие визуальные модификации: поворот, масштабирование, наклон и сдвиг. Чтобы сделать трансформацию, к селектору добавляется свойство transform, а в качестве значения пишется функция трансформации и её параметры. В общем виде это записывается так:
Трансформация — это изменение вида элемента, к которым относятся следующие визуальные модификации: поворот, масштабирование, наклон и сдвиг. Чтобы сделать трансформацию, к селектору добавляется свойство transform, а в качестве значения пишется функция трансформации и её параметры. В общем виде это записывается так:

         </p>
       <input class="button" type="submit"  value="Скачать!">

       <p><a class="arrowlast" href="">◄ Назад</a>&nbsp;<a class="arrowlast" href="">Вперед ►</a></p>

      <!-- <div id="ceytnt"><p>Полезна ли была для Вас информация сайта? Если да -</p>
          <h4>Поделитесь с друзьями!</h4>
            <script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script>
            <script src="//yastatic.net/share2/share.js"></script>
            <div class="ya-share2" data-services="vkontakte,facebook,odnoklassniki,moimir,gplus,twitter,lj" data-limit="3">
            </div>
       </div>-->
 <br>  
  
       <article id="commentary"><!--commentary-->
          <h3>Комментарии</h3>
            <p>Будь первым, кто оставит комментарий!</p> 
            <input type="hidden"><br>
            <input class="secondbutton js-secondbutton" type="button"  value="Комментировать!"><br>

                <div class="comment">
                   <p><a class="js-secondbutton" href="">Изменить</a></p> 
                     <address><p>Автор</p></address>
                   <p>Текст комментария</p>
                      <p>Дата</p>

        <input type="button" class="secondbutton js-secondbutton"  value="Ответить!">

           <div class="forForm" hidden>
             <a class="close js-close">Закрыть</a>
               <form method="POST">         
                   <fieldset>
                      Комментирует 'nickname'
                   </fieldset>
 
                   <fieldset>
                     <legend>Текст комментария:</legend>
                       <textarea cols="30" rows="15" name = "text" maxlength="1255" required >
      withcostomer,
                       </textarea>
                  </fieldset>        

                  <p>Введите, пожалуйста, результат сложения в окошко рядом с суммой <strong>790 + 240 = </strong></p>
            
                  <p><input type="text" name="contr_cod" maxlength="4" size="4" required autofocus></p>
     
                  <p><input type="submit" name="addcomment" class="button" value="Отправить" /><p>
               </form><br></div> 
          </div> 
 
      </article><!--end commentary--> 

    </article><!--end content--> 
                   
       <!--Главное меню сайта 2-3,3-4,auto-->
     <aside> 
       <nav id="middle">
          <ul>       
            <li> <a href="mysitemap.html">Карта сайта</a></li>
            <li><a href="">Menu</a></li> 
            <li><a href="">Menu</a></li>
          </ul> 

          <ul class="partforblock"><!--details -->
             <!--<p> summary -->
              <li class="menuforpart"><p class="js-menuforpart"><span> ►</span>&nbsp;&nbsp;Раздел: Длинное Имя раздела</p> 
            <!--</p>-->

                 <ul hidden>
                    <li>
                       <a href="">Ссылка на страницу</a>
                    </li> 

                     <li>
                       <p>
                         <i>
                           Текущая страница
                         </i>
                       </p>
                     </li> 

                     <li>
                        <a href="">Ссылка на страницу</a>
                     </li> 
                   </ul> 

                </li>
           </ul> 
          <ul class="partforblock"><!--details -->
             <!--<p> summary -->
              <li class="menuforpart"><p class="js-menuforpart"><span> ►</span>&nbsp;&nbsp;Раздел: Длинное Имя раздела</p> 
            <!--</p>-->

                 <ul hidden>
                    <li>
                       <a href="">Ссылка на страницу</a>
                    </li> 

                     <li>
                       <p>
                         <i>
                           Текущая страница
                         </i>
                       </p>
                     </li> 

                     <li>
                        <a href="">Ссылка на страницу</a>
                     </li> 
                   </ul> 

                </li>
           </ul>            
 <!-- end menu-->
      </nav>
    </aside><!--end menu-->

   <!--Правый базовый блок --> 
    <section id="baserightwrapper"><!--baserightwrapper 3-4,2-4,auto-->

          <picture>
            <source srcset="idea.svg">
            <img src="idea.png" alt="brend">
          </picture> 

              <h3>Замет&shy;ки на полях</h3>

    <!--Встраиваемый модуль--> 
       <br> 
       <section class="section">
  <h4>Реко&shy;мен&shy;дую</h4>
          <p><a href="">Вер&shy;стка: HTML, CSS</a></p>
          <p><a href="">PHP: Ma&shy;nu&shy;al</a></p>
        </section><!--end modul1-->  
    
     <!--Встраиваемый модуль --> 
        <hr> 
       <section class="section"><!--modul 1, Позиция 1-->
         <h4>Рекла&shy;ма</h4>
       </section><!--end modul 1-->
       <br>
    <!--Встраиваемый модуль--> 
      <section class="section"><!--modul 2, Позиция 2-->
<h4>Рекла&shy;ма</h4>           
      </section><!--end modul2-->
      
    <!--Встраиваемый модуль--> 
      <section class="section"> <!--modul 3, Позиция 3-->
<h4>Рекла&shy;ма</h4>          
      </section><!--end modul3-->    

   </section><!--end baserightwrapper --> 
</div>
   <!--Подвал 1-4,4-5,auto-->
     <footer>
      <address>Автор CMS KALINKA  Copyright © 2013 - 2018 Родионова Галина Евгеньевна. Все права защищены.
    </address>
       <a href=''>Обратная связь</a>
       <a href="" rel="nofollow">Документы</a>
       <a href="" rel="nofollow">О нас</a>
     </footer>

   </div><!--end basewrapper -->
  
      <script src="../../../lib/jquery/jquery-3.1.1.min.js"></script>

      <noscript> <p class='arrowlast'>Включите, пожалуйста, в Вашем Web-браузере поддержку JavaScript, если хотите что-либо скачать или прокомментировать на нашем сайте</p> 
      </noscript>
<script src="../../../lib/javascript.js"></script> 


  </body>
</html>

