<?php session_start();header("Content-Type: text/html; charset=utf-8");
define ( 'BUGIT', true );
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/	

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="robots" content="noindex, nofollow">
<link rel="stylesheet" href="../style.css"/> 
<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]--> 
<title>Шаблон</title></head>
<body><?php echo "<a href='$_SERVER[HTTP_REFERER]'>Вернуться</a>";?>
<div id="page">	
<?php include_once "../../../variables/variables.php";include_once "../../../variables/logotype.php";
echo '<div class="shapka"><div id="logo"><img src="../../../images/'.$logotype.'"/></div>
<div id="header"><h1>'.$heading.'</h1>'; ?><!--end header -->
 </div>
<div id="modulshdop"><p style="border:0.125em solid #5af22c;">Позиция модуля 1 для скачиваний. Для магазина - режим работы</p></div><!--end modulshdop-->
 </div>
<div class="top"><div id="topmenu">
<ul><li> 
topmenu
</li></ul>
</div></div> 
<div id="undershapka">Хлебные крошки\\ Позиция модуля 9<!--Закрыли крошки  --></div>
<div class="leftpaper"><!---Колонка 1--> 
<div id="shpk">Привет,admin!<br></div><br/>
<div id="news"><p style="border:0.125em solid #5af22c; margin-left:5%;">Это позиция 3(скачать, магазин) или 4(главная, статьи) под модуль modulpos12</p></div> <!-- end #news-->
 <div id="modu"><p style="border:0.125em solid #5af22c;">Это позиция 2(Общий) под модуль</p></div>
 <div id="mngl"><p style="border:0.125em solid #5af22c; margin-left:15%;">Главное меню</p>
<ul><li><a href="#">Пункт меню</a></li></ul></div>
</div> 
<div class='middl'><div>
<div id='conteiner'><p style="border:0.125em solid #5af22c;">позиция 7(Рекламное место - главная, статьи) под модуль </p>
<p style="border:0.125em solid #5af22c;">позиция 11(Условия - скачать, магазин) под модуль modulpos24</p>
</div>
<h2>Область контента</h2><p><img src="lazur1.jpg"  alt="Нет изображения"></p><p>Цветовая схема "Лазурь"(lazur)</p>
<p>Это позиция  под модуль Комментарии<p/>
</div></div> 
<div class="right"><!--Колонка 3-->
<div id="news"><p style="border:0.125em solid #5af22c;">Это позиция 10 (общий) под модуль</p><br/>
<p style="border:0.125em solid #5af22c;">Это позиция 6 (магазин, скачать) под модуль</p><br/>
<p style="border:0.125em solid #5af22c;">Это позиция 5(главная, статьи, скачать) под модуль</p>
</div> <!-- end #news-->
<div><p style="border:0.125em solid #5af22c;">Это позиция 8(главная, статьи, скачать) под модуль</p></div></div> </div>
<div class="footer"><p style="border:0.125em solid #5af22c; margin-left:5%;">Это позиция под модуль Обратной связи<p/><br/>
<p style="border:0.125em solid #5af22c; margin-left:5%;">			
</p>
</div><!-- end #footer -->
</body>	</html>	
