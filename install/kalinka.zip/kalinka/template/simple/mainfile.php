<?php   if(!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2018 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.0
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/	
?>
<!DOCTYPE html>
 <html lang="ru">
   <head>
     <meta charset="utf-8"/>
     <meta http-equiv="x-ua-compatible" content="ie=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />

<meta name="description" content="<?php if(isset($annotat) && isset($annotat[$id])) echo $annotat[$id];   ?>" />
<meta name="keywords" content="<?php if(isset($keywords) && isset($keywords[$id])) echo $keywords[$id];?>" />
<link rel="icon" href="favicon.ico" type="image/x-icon" />
     <link rel="stylesheet" href="template/simple/style.css" />
<title><?php if(isset($titlear) && isset($titlear[$id]))  echo $titlear[$id]; ?></title>
   </head>

   <body>
<!--Левый базовый блок -->
     <div id="basewrapper"><!--basewrapper 1-4, 1-,auto -->
       <div class="arrow">
         <p class="navdown" id="js-OnBottom">↓</p>
         <p class="navup" id="js-OnTop">↑</p>
       </div>

    <header>
      <nav id="top">
       <ul>
         <li>
          <a href="mysitemap.html">
            Карта сайта
          </a>
         </li>
        <?php
               if(isset($arrforblock))
                 foreach($arrforblock as $key=>$value) {
                    if(file_exists($key)) {
                 if($key==="book") {
      ?><li>
              <a href="index.php" title="<?php echo $value; ?>"><?php echo $value; ?>
              </a>
         </li> <?php
                     }
                   else {
         ?>
          <li>
            <a href="index.php?unit=<?php echo $key ?>" title="<?php echo $value; ?>"><?php echo $value; ?> </a>
          </li> <?php
                   }
              }
 } ?>
        </ul>
      </nav><!--menu-->

      <div class="formlogin"><a class="secondbutton js-secondbutton">Форма входа</a>
       <?php if(!isset($_SESSION['nickname'])) { 
           if(isset($pos[6])) {
                 $flname="modul/$pos[6]/def.php"; 
                  if(file_exists($flname)) 
                    include_once $flname;
                 } 
           }
           else { ?>
                <p>Добро пожа&shy;ло&shy;вать, 
                  <i><?php echo $_SESSION['nickname']; ?>!</i>
                </p>
                <p>
                 <a href='exit.php'>Выйти</a>
                </p>
             <?php } ?>
      </div><!--formlogin-->

    </header><!--header-->

    <div id="nav"><!-- 1-4, 2-3,108pxid="nav"-->
<!--Наименование текущей категории или ничего flex 1height:102px;-->
       <?php if(isset($numberpart) && $idpart[$id]!==0) echo "<h3>".$menupart[$numberpart]."</h3>"; ?>        

<!--Домен flex 2(flex 1-2 вложенный для буквицы)-->
      <div class="conteiner">
        <div class="firstpart">И</div>
        <div class="secondpart">мя сайта.ru</div>
      </div><!--end conteiner-->
    
     <div class="clear"></div> 
   </div><!--end nav-->

   <div class="conteinerarticle">           
      <!--Статья-->    

       
       <!--Главное меню сайта 2-3,3-4,auto-->
    <aside> 
       <nav id="middle">
<?php
//Боковое меню
             if(file_exists("variables/menusd.php")) 
                include_once "menu/$menusd/menuside.php";
             else 
                include_once "menu/menusimple/menuside.php";
?>
        </nav>
    </aside><!--end menu-->

     <article id="forarticle"><!--content-->
        <?php
           if(isset($unit)) { 
              if(isset($pos[17])) {
                  $viewvideo=$unit.$id;
              if(file_exists("modul/$pos[17]/$unit/")) {

    if(file_exists("modul/$pos[17]/$unit/$viewvideo.ogg")) {
                     if(isset($pos) && isset($pos[17]))  {
                         $flname="modul/$pos[17]/def.php";
                         if(file_exists($flname))
                           include_once $flname;
                          }  
                    } 
                 }                    clearstatcache();
               } 
           
          if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar) && isset($titlear[$id]) && isset($contentar[$id]) && isset($authorar[$id]) && isset($datar[$id])) {
                        echo "<h1> $titlear[$id]</h1>";
                        echo  $contentar[$id];
                        echo "<address>";echo $authorar[$id]."</address>";
                        echo "<p>".$datar[$id]."</p>";
                }
echo "<br>";
         if(isset($pos[18])) {
           $flname="modul/$pos[18]/def.php";
           if(file_exists($flname))
             include_once $flname;
            }
               switch($unit) {
                    case 'payware':
                     //Модуль Купить  
                    break;

                    case 'shop':
                     //Модуль Купить                       
                    break;

                    default:
                     //Модуль Скачать
                       if(isset($id) && $id>1) {
                              if(isset($pos[19])) {
                                $flname="modul/$pos[19]/def.php";
                                    if(file_exists($flname))             
                                         include_once $flname;
                             }  
                         }       
                   break;   
                   }
          }          
?><br>

       <!--<div id="ceytnt"><p>Полезна ли была для Вас информация сайта? Если да -</p>
         <h4>Поделитесь с друзьями!</h4>
            <script type="text/javascript" src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js" charset="utf-8"></script>
            <script type="text/javascript" src="//yastatic.net/share2/share.js" async="async" charset="utf-8"></script>
            <div class="ya-share2" data-services="vkontakte,facebook,gplus,twitter,blogger" data-counter=""></div>
       </div>-->


   <br> 
 
    <article id="commentary"><!--commentary-->
      <?php 
         if(isset($pos[12])) {
           $flname="modul/$pos[12]/def.php";
           if(file_exists($flname))
             include_once $flname;
            } ?>   
    </article><!--end commentary-->
   </article><!--end content--> 

   <!--Правый базовый блок --> 
      <section id="baserightwrapper"><!-- baserightwrapper 3-4,2-4,auto -->
          <picture>
            <source srcset="images/book/.svg">
            <img src="images/book/.png" alt="">
          </picture> 

              <h3>Замет&shy;ки на полях</h3>

    <!--Встраиваемый модуль--> 
       <br> 
       <section class="section"><!--section 1-->
  <h4>Реко&shy;мен&shy;дую</h4>
          <p><a href="">Вер&shy;стка: HTML, CSS</a></p>
          <p><a href="">PHP: Ma&shy;nu&shy;al</a></p>
        </section><!--end modul1-->   
    <hr> 
     <!--Встраиваемый модуль --> 
       <section class="section"><!--section 2-->
                  <h4>Рекла&shy;ма</h4>
           <?php if(isset($unit)) {
                   if(isset($pos[1])) {
                     $flname="modul/$pos[1]/def.php";
                       if(file_exists($flname))
                         include_once $flname;
                         }
                    } ?>
       </section><!--end modul 2-->
       <br>
    <!--Встраиваемый модуль pos[4]--> 
      <section class="section">
         <h4>Рекла&shy;ма</h4>
           <?php if(isset($unit)) {
                   if(isset($pos[2])) {
                     $flname="modul/$pos[2]/def.php";
                       if(file_exists($flname))
                         include_once $flname;
                         }
                    } ?>
      </section><!--end modul4-->
      <br> 
    <!--Встраиваемый модуль--> 
       <section class="section"> <!--modul 4, Позиция 5-->
         <h4>Рекла&shy;ма</h4>
           <?php if(isset($unit)) {
                   if(isset($pos[3])) {
                     $flname="modul/$pos[3]/def.php";
                       if(file_exists($flname))
                         include_once $flname;
                         }
                    } ?>
          </section><!--end modul4-->    

       </section><!--end baserightwrapper --> 
     </div><!--end  conteinerarticle--> 
   <!--Подвал 1-4,4-5,auto-->
     <footer>
      <address>Автор CMS KALINKA  Copyright © 2013 - 2018 Родионова Галина Евгеньевна. Все права защищены.
      </address>
<?php if(isset($menutit)) 
              foreach($menutit as $keycm=>$valcm) { ?>
                  &nbsp;&nbsp;&nbsp;
                <a href="common/commonrules.php?page=common&amp;id=<?php echo $keycm ?>" rel="nofollow"><?php echo $valcm ?></a>
              <?php } ?>
     </footer>
   </div><!--end basewrapper -->
   <?php  if(file_exists("lib/jquery/jquery-3.1.1.min.js")) { ?>
      <script src="lib/jquery/jquery-3.1.1.min.js"></script>
<?php     } ?>
      <noscript> <p class='arrowlast'>Включите, пожалуйста, в Вашем Web-браузере поддержку JavaScript, если хотите что-либо скачать или прокомментировать на нашем сайте</p> 
      </noscript>

      <?php 
    if(file_exists("basket/basketpw")) { ?>
      <script src="basket/basketpw/jvs.js"></script>
    <?php } ?>
      <script src="lib/beforemain.php"></script>
<!-- Yandex.Metrika counter -->
<!--<script type="text/javascript">
    (function (d, w, c) {
        (w[c] = w[c] || []).push(function() {
            try {
                w.yaCounter40622225 = new Ya.Metrika({
                    id:40622225,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true
                });
            } catch(e) { }
        });

        var n = d.getElementsByTagName("script")[0],
            s = d.createElement("script"),
            f = function () { n.parentNode.insertBefore(s, n); };
        s.type = "text/javascript";
        s.async = true;
        s.src = "https://mc.yandex.ru/metrika/watch.js";

        if (w.opera == "[object Opera]") {
            d.addEventListener("DOMContentLoaded", f, false);
        } else { f(); }
    })(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/40622225" style="position:absolute; left:-9999px;" alt="" /></div></noscript>-->
<!-- /Yandex.Metrika counter -->
 </body>
</html>

