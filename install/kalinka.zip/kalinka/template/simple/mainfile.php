<?php  if (!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<div id="page"><!-- --><div class="shapka"><!--shapka -->
<div id="logo"><!--logo --><?php if(isset($logotype)) echo '<img src="images/'.$logotype.'" alt="LOGOTYPE"/>'; ?></div><!--end logo-->
<div id="header"><!--header --><?php echo '<h1>'.$heading.'</h1>'; ?>
</div><!--end header-->
<!--noindex--><div id="modulshdop"><!--modulshdop --><!--Позиция модуля 1 -->
<?php 
if(isset($unit))
{
//позиц.1
switch($unit){
case 'shop':if(file_exists("shop/regim.php"))
{$flname="shop/regim.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;
}
break;
case 'freeware':
if(isset($pos) && isset($pos[1]))
{$flname="modul/$pos[1]/def.php";if (file_exists($flname))if (file_get_contents($flname)) include_once $flname;}
break;
}}
?>
</div><!--end modulshdop--><!--/noindex--><div class="upshapka"></div>
</div><!--end shapka-->
<!-- Верхнее главное меню -->
<div id="topmenu"><!--topmenu --> 
<?php $filename="menu/topmenu/topmenu.php";
if (file_exists($filename)) include_once 'menu/topmenu/topmenu.php';
?></div><!--end topmenu--><div class="upshapka"></div>
<!--</div>--><!--end top--><!--noindex-->
<div id="undershapka"><!--undershapka --><?php  if(isset($unit) && $unit==="payware") {if(file_exists("basket/basketpw/basket.php")) { 
if(isset($id) && $id!==1){if(isset($thiscost[$id])) 
include_once "basket/basketpw/basket.php";
}
}} else { ?><b>Компас для всех!</b><?php } ?>
</div><!--end undershapka-->
<div class="leftpaper"><!-- left-->
<div id="shpk"><!--shpk --><p>Для увеличения изображения нажмите на него</p></div><!--end shpk-->
<div class="news"><!--news --><?php
 if(isset($unit)) {switch($unit){
case 'book':
if(isset($pos[4]))
{$flname="modul/$pos[4]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
case 'shop':
if(isset($pos[3]))
{$flname="modul/$pos[3]/def.php";
if (file_exists($flname))
if (file_get_contents($flname))	include_once $flname;}
break;
case 'freeware':
if(isset($pos[4]))
{$flname="modul/$pos[4]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
}} else {if(isset($pos[4]))
{$flname="modul/$pos[4]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}}
?>
</div> <!-- end news-->
<div id="modu"><!--modu -->
<?php if(isset($pos[2]))
{$flname="modul/$pos[2]/def.php"; if (file_exists($flname)) include_once $flname;} ?>
</div><!-- end modu--><!--/noindex-->
 <?php
//Боковое меню
if (file_exists("var/menusd.php")) include_once "menu/$menusd/menuside.php";
else include_once "menu/menusimple/menuside.php";
?><!-- end menu-->
</div><!-- end left-->
<div class='middl'><!-- --><div id="conteiner"><!-- --><!--noindex--><div id='cnt'><!--cnt -->
<?php
//'Это позиции 7или 9 под модуль';
 if(isset($unit)) {switch($unit){
case 'book':
if(isset($pos[7])) {$flname="modul/$pos[7]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
case 'shop':
if(isset($pos[9])) {$flname="modul/$pos[9]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
case 'freeware':
if(isset($pos[9])) {$flname="modul/$pos[9]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;   	
}} else {if(isset($pos[7])) {$flname="modul/$pos[7]/def.php";
if(file_exists($flname))
if(file_get_contents($flname)) include_once $flname;}}
?>
</div><!-- end cnt--><!--/noindex-->
<?php ///////////////////////////////////////////////////////Область контента
if(isset($unit)) {
if(file_exists("main$unit.php")) include_once "main$unit.php";
if($unit==="freeware") {if(file_exists("freeware/freeload.php")) include_once "freeware/freeload.php";}
if($unit==="comm") {if(file_exists("common/infomaster.php")) include_once "common/infomaster.php";}
}
 ?>
</div><!-- end conteiner-->
<?php if(isset($pos) && isset($pos[12]))
{$flname="modul/$pos[12]/def.php";if (file_exists($flname))if (file_get_contents($flname))include_once $flname;}?>
</div><!-- end middl-->
<!--noindex--><div class="right"><!--right --><!--Колонка 3-->
<div class="news"><!--news -->
<?php  //Позиция 6
if(isset($pos[6]))
{$flname="modul/$pos[6]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
?>
</div><!--end news--><?php
if(isset($unit)) switch($unit)
{case 'freeware':
echo "<div id='forpred'>Скачивая продукт, Вы принимаете условия Соглашения</div><br>";
break;
case 'shop':
echo "<div id='forpred'><p>Оплачивая продукт, Вы выражаете согласие с Договором оферты.</p></div><br>";
break;
} ?>
<div class="news"><!--news --><?php
//Позиция 10
if(isset($pos[10]))
{$flname="modul/$pos[10]/def.php"; if (file_exists($flname)) include_once $flname;}	
?>
</div><!--end news-->		 
<div id='md'><!-- md-->				
 <?php //Позиция 5
if(isset($unit)) {switch($unit){
case 'book':
if(isset($pos[5]))
{$flname="modul/$pos[5]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
case 'freeware':
if(isset($pos[5]))
{$flname="modul/$pos[5]/def.php";
if (file_exists($flname))
if (file_get_contents($flname))	include_once $flname;}
break;
}} else {if(isset($pos[5]))
{$flname="modul/$pos[5]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}}
 ?>
</div><!--end md -->			 
<div class="news"><!--div --> 			 
<!-- Позиция модуля 8--><?php
if(isset($unit)) {switch($unit){
case 'book':
if(isset($pos[8])) {$flname="modul/$pos[8]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}
break;
case 'freeware':
if(isset($pos[8])) {$flname="modul/$pos[8]/def.php";
if (file_exists($flname))
if(file_get_contents($flname)) include_once $flname;}
break;   	
}} else {if(isset($pos[8])) {$flname="modul/$pos[8]/def.php";if(file_get_contents($flname)) include_once $flname;}}
 ?>	
</div> <!--end div--></div><!--/noindex--><!--end right--><div class="upshapka"></div></div><!--end page -->
<div class="footer"><!--footer -->
Сайт работает на <a href="https://unatka.ru">CMS KALINKA</a>. Copyright © 2013- 2016 Родионова Галина Евгеньевна. Все права защищены.<br>
<?php 
//Обратная связь
if(isset($pos[16]))
{$flname="modul/$pos[16]/def.php";
if(file_exists("modul/$pos[16]/def.php")) echo "<a href='modul/$pos[16]/def.php'>Обратная связь</a>"; 
}
//Страница О нас
if(file_exists("common/infomaster.php")) echo "&nbsp;&nbsp;&nbsp;<a href='index.php?unit=comm'>О нас</a>";if(file_exists("modul/mddoclist/")) {
?><p><a href="modul/mddoclist/rules.php?rules=zajavl&amp;page=common" rel="nofollow"  target="_blank">Конфиденциальность</a><a href="modul/mddoclist/rules.php?rules=pravila&amp;page=common" rel="nofollow" target="_blank">Правила</a></p><?php } ?>
</div><!--end footer-->
<?php
if(isset($pos[15]))
{$flname="modul/$pos[15]/def.php";
if (file_exists($flname))
if (file_get_contents($flname)) include_once $flname;}	
?>
