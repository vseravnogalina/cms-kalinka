<?php if (!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2018 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.3
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<!--noindex-->
<?php

    if(!isset($_SESSION['nickname'])) {
?>
        <!---->
         <div id="linkancor" class="forForm" > <!--class="forForm"-->
          <a class="close js-close">Закрыть</a>
          <form  method="POST">
            <fieldset>
               <legend><mark><i>Форма входа</i></mark></legend>
               <input type="hidden" name="groupcostomer" value="4"/>
            <p><input type="text" name="nickname" value="" placeholder="Ваше имя:" required /></p>
            <p><input type="email" name="eml" value="" placeholder="E-mail:" required /></p>
            <p><input type="checkbox" name="agry" value="1" checked />Я согласен(на) на обработку моих персональных данных
              <input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR'] ?>" >
             <p><input type="submit" name="enter"  class="button"  value="Войти!" /></p>
           </fieldset>
         </form> 
      </div><!--forForm-->
<?php
  }
?><!--/noindex-->
