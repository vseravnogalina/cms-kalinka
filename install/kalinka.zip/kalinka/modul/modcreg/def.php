<?php if (!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<!--noindex-->
<META HTTP-EQUIV="Cache-control" CONTENT="NO-CACHE, must-revalidate">
<?php
$time=date(":d:m:y");
$timetek=date("H:d:m:y");
if(isset($unit)) if($unit==='shop')
{if(preg_match("/^(2)+([2-4]{1})+($time)$/i",$timetek))
{die("Мы закрыты на технический перерыв. Приносим извинения за причиненные неудобства.");}
if(file_exists("basket/shopbasket")){if(file_exists("shop/yes.txt") && !isset($shet))
{die("Магазин временно не работает. Приносим извинения за причиненные неудобства.");}
}}
if(isset($unit)){
if(isset($_SESSION['nickname'])) {echo "<p class='p1'>Добро пожаловать, <b>$_SESSION[nickname]!</b></p><div id='shpk'><a href='exit.php'>Выйти</a></div>";}
else
{
?>
<b>Форма входа</b><br>
<form class="shapform" method="POST">
 <input type="hidden" name="groupcostomer" value="2"/>
<p><input type="text" name="imvh" value="" placeholder="Ваше имя:" required  autofocus/></p>

<p><input type="text" name="eml" value="" placeholder="E-mail:" required /></p>
<input type="hidden" name="ip" value="<?php echo $_SERVER['REMOTE_ADDR'] ?>" >
<p><input class="subt" type="submit" name="regsub"   value="Войти!" /></p>
</form><br>
<?php
}}
?><!--/noindex-->
