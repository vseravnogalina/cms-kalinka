<?php if (!defined('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Выводим информацию и формы
if(isset($recomend) && $recomend==="YES") echo "Переключите шаблон перед удалением!";
?>
<h3>ШАБЛОНЫ</h3>
<?php
if (file_exists("../variables/vartempl.php")) 
{include_once  '../variables/vartempl.php';
echo "<h4>В настоящий момент установлен шаблон $osnova</h4>";
} else $osnova="simple";
?>
<h3>Установка шаблона</h3>
<form class="sel" method="POST" enctype="multipart/form-data">
<p><input type="file" name="uploadfile"><input type="submit" name="add" value="Загрузить шаблон"></p></form>
<h3>Список шаблонов</h3>
<?php
if(isset($shablon))
{
foreach($shablon as $key=>$val)
{ ?>
<form class="bord" method="POST"><?php if($val!=='simple')
{ ?>
<input class="knopdel" type="submit" name="delud" value="Удалить" >
<?php } ?>
Наименование<input type="text" name="tem" value="<?php echo $val ?>"><input class="two" type="hidden" name="chvid" value="template">
<a title="щелкните по ссылке, чтобы посмотреть макет с указанием позиций модулей" target='_blank' href="../template/<?php echo $val ?>/maket/maket_<?php echo $val ?>.php">Посмотреть макет</a>
<?php
if(isset($osnova) && $val!==$osnova)
{ ?>
<input class="knop" type="submit" name="podkl" value="Подключить" >
<?php
}
?>
</form>
<?php }} ?>
