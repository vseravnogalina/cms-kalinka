<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2019 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.5
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/ 
?><h4>Список установленных узлов</h4>
<table class="bord"> 

    <tr>
      <td  class="bord"><p>Имя узла</p></td>

<?php
        if(isset($arrblock)) 
          foreach($arrblock as $k=>$v) 
            if(file_exists("$k")) if($k!=="common") { ?>
              <td  class="bord"><p><?php echo $v ?></p></td>
<?php          } ?>
    </tr>
</table>
<h3>Установка дополнительных узлов</h3> <p>например, блог</p>

                 <?php if(isset($arrblock) && count($arrblock)!==0) { ?>
           <form method='POST'>         
                   <select name="unitline">
                         <option>Выбрать</option>
                             <?php if(isset($arrblock)) 
                                        foreach($arrblock as $key=>$val) {
                 //Если узла нет
                   if(!file_exists("$key") && $key!=="common" && $key!=="book") {
                ?><option value="<?php echo $key;?>"><?php echo $val;?></option><?php 
                    }  
                  } ?>
                    </select>
                 <input type="submit" value="Установить">
           </form> 
 <?php 
             } ?>

<h3>Удаление дополнительных узлов</h3>
<form method='POST'><p>
<?php
if(isset($arrblock))
 foreach($arrblock as $k=>$v) {
  if(file_exists("$k") && $k!=="common" && $k!=="book") {
     echo '<input name="radiobutton" type="radio" value="'.$k.'" />'.$v;
   } 
}
?>
<input type='submit' name='dispose' value="Удалить узел!" />
</form> 
<h3>Администрирование - Главная страница </h3>
