<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(file_exists("../variables/logotype.php")) {include_once("../variables/logotype.php"); echo "Установлен логотип: $logotype<br>";}
if(file_exists("../variables/variables.php")) {include_once("../variables/variables.php"); echo "Текущее наименование сайта $heading";}
?>
<h3>Установить логотип</h3>
<form enctype="multipart/form-data" method="POST">
<input type="hidden" name="MAX_FILE_SIZE" value="30000" />
Выбрать файл: <input name="userfile" type="file" accept="image/*,image/jpeg"/>
<input type="submit" name="savelogot" value="Сохранить" />
</form><br>
<h3>Изменить название сайта</h3>
<form method="POST">
Введите название сайта
<input type="text" name="ttl" value="<?php if(isset($heading)) echo $heading ?>"/>
<input type="submit" name="otpr" value="Изменить название сайта"/>
</form>
