<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');
      if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна https://unatka.ru * @copyright Copyright © 2013-2019 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.5
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
 
//Форма загрузки дополнений: 1. Выбрать узел для установки 2. Выбрать файл кнопкой Обзор 3. Загрузить дополнение
//Форма удаления 
if(isset($radiobutton)) {

?>
<a href="avpult.php?unit=common&common=forextra.php">Изменить выбор узла</a>

    <h3>Загрузка </h3>
      <h4>Подготавливаются дополнения узла <?php echo $newr; ?> </h4>
          <form class="bord" enctype="multipart/form-data" method="POST">
 
               <p>Выбрать файл:
               <input name="uploadfile" type="file" />

               <input type="submit" name="add" value="Загрузить" /></p>
           </form>
<?php }

    if(empty($radiobutton)) {
          selectUnit($arrblock);
        } ?>
<h3>Администрирование узла Общее - загрузка Дополнений к узлу</h3>
