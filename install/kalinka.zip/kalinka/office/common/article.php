<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<div id="tovar" >
<p><a href="<?php echo $_SERVER['HTTP_REFERER'] ?>">Отказаться</a></p>
<a class="show" href="#">Показать номера сортировки</a><div id="blockim"><a href="#" class="close">Свернуть</a><br>
<?php
if(isset($titlelist)) foreach($titlelist as $key=>$val) {echo "<br>Статья: ".$val." Номер сортировки: ".$key."<br>";} ?></div>
<?php if(file_exists("modul/zvplatkartinky/def.php")) include_once "modul/zvplatkartinky/def.php"; ?>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<h3>Статья:<?php if(!empty($namearticle)) echo $namearticle; else echo "Новая статья";?></h3>
<form method='POST'><?php  { ?>

<?php }
if(isset($redactor) && $redactor===1) { 
if(isset($titlelist)) { ?><p>Номер сортировки: </p>
<p><input type='text' name='listarticle' value="<?php if(isset($listarticle)) echo $listarticle ?>"  /></p><p><input type='hidden' name='id' value="<?php if(isset($id)) echo $id; ?>"/></p><?php }}
if(isset($redactor)) {  ?>
<p> <input type='hidden' name='redactor' value="<?php echo $redactor ?>" required /></p><?php }  ?>
<p>Раздел: </p>
<?php
if(isset($part)) { if($redactor===0) { ?>
<p><input type='text' name='part' value="<?php echo $part ?>" required  placeholder="Имя раздела или 0" title="Если разделы не нужны, оставляем 0, если пишем ключевую статью - имя раздела должно совпадать с именем статьи" /></p><?php } 
else { ?><p><input type='text' name='part' value="<?php echo $part ?>" required  placeholder="Имя раздела или 0" title="Изменяем имя раздела командой 'Переименовать раздел'" readonly /></p> <?php }} ?>
<!--<p title="Если в разделе не нужны главы, оставляем 0">Глава: </p>--><?php
/*if(isset($chapter)) { ?>
<p><input type='text' name='chapter' value="<?php echo $chapter ?>" placeholder="Имя главы или 0" title="Если в разделе не нужны главы, оставляем 0, если пишем ключевую статью - имя раздела должно совпадать с именем главы и с именем статьи" /></p><?php }*/
if(isset($id) && isset($titlear[$id])) { ?>
<p>Заголовок**:</p><p> <input type='text' name='title' value="<?php echo $titlear[$id] ?>" required/></p><?php }
else { ?>
<p>Заголовок**:</p><p> <input type='text' name='title' value='' placeholder="Заголовок статьи" required/></p> <?php }
if(isset($unit) && $unit==="payware") {if(isset($redactor) && $redactor===1){
if(isset($id) && isset($assortcost[$id])) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value="<?php echo $assortcost[$id]  ?>" required/></p><?php }}
else {if(isset($part) && $part!==0) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value='' placeholder="Цена, руб" required /></p> <?php } else { if($id>1) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value='' placeholder="Цена, руб" required /></p> <?php }} }
}
if(isset($unit) && $unit==="shop") {if(isset($redactor) && $redactor===1){
if(isset($id) && isset($assortcost[$id])) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value="<?php echo $assortcost[$id]  ?>" required/></p><?php }}
else {if(isset($part) && $part!==0) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value='' placeholder="Цена, руб" required /></p> <?php } else { if($id>1) { ?>
<p>Цена, руб:</p><p> <input type='text' name='costprod' value='' placeholder="Цена, руб" required /></p> <?php }} }
}
if(isset($id) && isset($kwar[$id])) { ?>
<p>Ключевые слова:</p><p> <input type='text' name='keywords' value="<?php echo $kwar[$id] ?>" /></p><?php }
else  { ?><p>Ключевые слова:</p><p><input type='text' name='keywords' value='' placeholder="Ключевые слова" ></p> <?php }
if(isset($id) && isset($annotar[$id])) { ?>
<p>Аннотация:</p><p> <textarea cols='40' rows='10' name='annot' value="<?php echo $annotar[$id] ?>" /><?php echo $annotar[$id] ?></textarea></p> <?php }
else { ?> "<p>Аннотация:</p><p> <textarea cols='40' rows='10' name='annot' value=''/></textarea></p><?php } 
if(isset($id) && isset($authorar[$id])) { ?>
<p>Автор:</p><p><input type='text' name='author' value="<?php if(isset($authorar[$id])) echo $authorar[$id]; ?>"/></p> <?php } 
else {?>
<p>Автор:</p><p><input type='text' name='author' value=""/></p> <?php
}
if(isset($id) && isset($datar[$id])) { ?><p>Дата публикации:</p><p><input type='text' name='dat' value="<?php if(isset($datar[$id])) echo $datar[$id]; ?>"/></p> <?php } 
?>
<p>ТЕКСТ**:</p> <?php 
if(isset($id) && isset($contentar[$id])) { ?>
<textarea id='editor1' name='mess'><?php echo $contentar[$id]; ?></textarea><?php }
else { ?> <textarea id='editor1' name='mess'></textarea><?php } ?>
<script>var ckeditor1 = CKEDITOR.replace('editor1');</script><br><input class='knop' type='submit' value="Сохранить статью" name='save'/>
<?php if(isset($redactor) && $redactor===1 && $id!==1) { ?>
<br><input class='knopdel' type='submit' value="Удалить статью" name='delst'/>
</form>
<?php } ?>
</div> <?php
