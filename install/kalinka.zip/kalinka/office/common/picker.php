<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?><h3>Организовать контент</h3>
<div id="pickarticle"><?php if(isset($menupart) && count($menupart)!==0) { ?>
<select id="partselect"><option>Выбрать Раздел</option><?php if(isset($menupart)) 
foreach($menupart as $key=>$val) { ?><option value="<?php echo $key;?>"><?php echo $val;?></option><?php } ?>
</select> <?php } ?>
<form class="knop" method="POST" title="Для разбивки по разделам отметить нужные статьи и нажать 'Добавить в раздел'(предварительно выбрать раздел), для извлечения из раздела - выбрать статью и нажать Сделать простой, чтобы сделать простую статью ключевой раздела - выбрать статью и нажать Сделать ключевой. Ключевые статьи разделов -  обведены белой рамкой. Переименовать раздел - выбрать раздел, вписать новое имя , нажать Переименовать" >
<p><?php if(isset($menupart) && count($menupart)!==0) { ?><input style="background:url(images/buttonadd.png) no-repeat;width:6em;height:6em;color:#fff;" type="submit" value="В раздел" /><input style="background:url(images/buttonsimple.png) no-repeat;width:6em;height:6em;color:#fff;" type="submit" name="simplearticle" value="Простая" /><input type="text" name="part" value="" placeholder="Новое имя раздела"  /><input type="submit" name="replpart" value="Переименовать" /><?php } ?><input style="background:url(images/buttonkey.png) no-repeat;width:6em;height:6em;color:#fff;" type="submit" name="klarticle" value="Ключевая" /></p>
<p><input class="part" type="hidden" name="numberpart" value="" placeholder="id раздела" readonly /></p> <h4>Список статей</h4><?php 
if(isset($menutitun)) foreach($menutitun as $k=>$v) {if(isset($menupart) && array_search($v,$menupart)){?>
<span  style="border:solid 2px #fff;"><input type="checkbox" name="picker[]" value="<?php echo $k; ?>" /><?php echo $v; ?></span>
<?php } else { ?><input type="checkbox" name="picker[]" value="<?php echo $k; ?>" /><?php echo $v;  }
} ?>
</form>
</div>
