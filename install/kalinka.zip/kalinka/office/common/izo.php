<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(isset($radio)) {
?>
<a href="avpult.php?unit=common&common=izo.php">Изменить выбор узла</a>
<h5 style='background-color:#fff000'>NB!Позволена загрузка изображений формата jpg,jpeg,svg размером не более 800*600px! При попытке загрузки других форматов загрузка прекращается!</h5>
<p>Имена файлов должны быть записаны на латинице,например, не картинка.jpg, а kartinka.jpg</p>
<h3>Загрузка изображений</h3>
<h4>Подготавливаются изображения узла <?php echo $newr; ?> </h4>
<form enctype="multipart/form-data" method="POST">
<input type='hidden' name='radio' value="<?php echo $radio ?>" />
<input type='hidden' name='des' value="izo" />
<?php for ($i=0; $i<9; $i++) { ?>
<p>Выбрать файл:</p> <input name="userfile[]" type="file" accept="image/*,image/jpeg" />
<?php } ?>
<input type="submit" name="add" value="Загрузить" /></p>
</form>
<?php }
if(isset($izo) && count($izo)>0)
{echo "<h3>Загружены изображения</h3>";
echo '<form method="POST"><input type="hidden" name="radio" value="'.$radio.'" />
<select name="delizo" size=1>';
foreach($izo as $val)
 {echo '<option>'.$val.'</option>';}
echo '</select>
<input type="submit" value="Удалить!"></form>';
} 
if(empty($radio)) { ?>
<h3>Выбор узла загрузки изображений</h3>
<form method='POST'><p>
<?php
if(isset($arrblock))
foreach($arrblock as $k=>$v)
{if (file_exists("$k")) {if($k==="book")
echo '<input name="radio" type="radio" value="'.$k.'" checked/> '.$v;
else
echo '<input name="radio" type="radio" value="'.$k.'" /> '.$v;
}}
?>
<input type='submit' value="Выбрать узел!" />
</form> <?php } ?>
