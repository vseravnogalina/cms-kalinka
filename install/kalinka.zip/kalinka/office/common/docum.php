<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/	?>
<p>Привет! Здесь оформляются документы сайта!</p>
<?php
//Доклад
if(isset($radiodocum) && isset($buttondoc) && $buttondoc!=="infomaster")
{if(!file_exists("../$radiodocum/$buttondoc.php")) 
echo "<h5>Данные $arrpravila[$buttondoc], $arrblock[$radiodocum] отсутствуют!</h5>";
else echo "Данные $arrpravila[$buttondoc], $arrblock[$radiodocum] успешно сохранены <br>";	
} 
if(!file_exists("../common/infomaster.php")) echo "<h5>Данные о мастере или компании отсутствуют!</h5>";
else echo "Данные о мастере или компании  успешно сохранены <br>";
if(isset($radiodocum) && $radiodocum==='shop')
{if (!file_exists("../shop/regim.php"))  
echo "<h5>Данные о режиме работы магазина отсутствуют!</h5>";
else echo "Данные о режиме работы магазина успешно сохранены <br>";
}
if(isset($radiodocum) && empty($buttondoc))
{//После выбора узла выбираем тип документа
?>
<H4>Создать документы</H4>
<form method='POST'>
<input name="radiodocum" type="hidden" value="<?php echo $radiodocum ?>" />
<p>
<input name="buttondoc" type="radio" value="pravila" checked />
Пользовательское соглашение
<?php
if(isset($radiodocum) && $radiodocum==='shop' || $radiodocum==='freeware')
{ ?> 
<input name="buttondoc" type="radio" value="spos" checked  /> 
Как приобрести? </p><?php } ?>
<input name="buttondoc" type="radio" value="zajavl" /> 
Заявление о конфиденциальности
<?php
if(isset($radiodocum) && $radiodocum==='shop')
{ ?> 
<input name="buttondoc" type="radio" value="regim" />
Информация о магазине
<?php } ?>
<?php
if(isset($radiodocum) && $radiodocum==='common')
{ ?> 
<input name="buttondoc" type="radio" value="infomaster" /> 
О нас </p><?php } ?>
<input type='submit' value="Выбрать тип документа" />
</form>
<?php } if(empty($radiodocum)) { ?>
<H4>Выбрать узел</H4>
<form method='POST'><p>
<?php
if(isset($arrblock))
foreach($arrblock as $k=>$v)
{if (file_exists("$k")) 
{if($k!=="common")
echo '
<input name="radiodocum" type="radio" value="'.$k.'" /> 
'.$v;else echo '
<input name="radiodocum" type="radio" value="'.$k.'" checked/> 
'.$v;
} 
}
?>
<input type='submit' name='' value="Выбрать узел" />
</form> <?php }
//Выводим редактор для создания, редактирования и сохранения документов
if(isset($radiodocum))
{if(isset($buttondoc)) {
?><a href="avpult.php?page=common&common=docum.php">К началу</a>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script> 
<?php if(isset($arrblock[$radiodocum])) { ?>
<h3> для узла <?php echo $arrblock[$radiodocum] ?><h3> <?php } ?>
<form method='POST'>
<input name="buttondoc" type="hidden" value="<?php echo $buttondoc ?>" />
<input name="radiodocum" type="hidden" value="<?php echo $radiodocum ?>" />
<p>Текст</p>
<textarea id='editor1' name='poleosn' cols='100' rows='20' value="<?php $poleosn ?>">
<?php
if (isset($buttondoc)) {
if(file_exists("../$radiodocum/$buttondoc.php")) include_once"../$radiodocum/$buttondoc.php";}
?>
 </textarea><script>var ckeditor1=CKEDITOR.replace('editor1');</script><br>
 <input type='submit' name='savedocum' value='Сохранить' />
 <input type='submit' name='deldocum' value='Удалить' />
</form><?php }} ?>
