<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;} 
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Подключаем модуль переменного подключения
if(isset($podkl))
//Если модуль постоянного подключения - вызываем позицию из массива
{if(isset($imjaengav))
{if(isset($immod[$imjaengav]["con"]) && $immod[$imjaengav]["con"]===0)
//Выводим выбор позиции
{if(isset($imjaru))
{//Выбираем номер позиции
$number=range(1,10);echo "<b>Выбор позиции модуля $imjaru</b>";
?>
<form method=POST><input class="two" type="hidden" name="chvid" value="modul"><input class="two" type="hidden" name="podkl" value="<?php echo $podkl; ?>" ><input type="hidden" name="imjaengav" value="<?php echo $imjaengav ?>"><input type="text" name="imjaru" value="<?php echo $imjaru ?>" readonly >
<select name="nomerpos" size=1>
<?php
//В цикле вставляем функцию rang
 foreach($number as $val)
 {echo '<option>'.$val.'</option>';}
 ?>
</select>
<input type=submit name=viborpos value="Установить модуль в позицию!">
</form>
<?php
}
}

}
}

//Выводим информацию на монитор, а также форму загрузки
?>
<h3> МОДУЛИ САЙТА</h3><h4>Позиции модулей в зависимости от блока</h4>
<table class="bord"><tr><td>Общие(Для <br>всех блоков):<br> 2, 6, 10</td><td>Главная,<br> Статьи:<br> 4, 5, 7, 8</td><td><br>Скачивания:<br> 1, 3, 4, 5, 8, 9</td><td><br>Купить:<br>1, 3, 9</td><td><br>Магазин:<br>1, 3, 9</td>
</tr></table>
<h4>Модули постоянного подключения(позиции)</h4>
<table class="bord">
<tr><td>Кнопка навигации<br>по вертикали):<br>15</td>
<td>Обратная<br>связь:<br>16</td><td><br>Комментарии:<br>12</td>
<td>Кнопка навигации<br>между страницами:<br>18</td><td>Дополнительный<br>указатель:<br>19</td></tr></table>
<div class="model">
<?php
if(empty($ustanov))
{
?>
<h3>Добавить модуль</h3>
<p>** Поле, обязательное для заполнения!</p>
<form class='sel' method='POST' enctype='multipart/form-data'>
<p title="Введите любое, удобное для Вас, название">Имя модуля на русском языке**</p>
<p><input  type='text' name='imjaruav' value='' required ></p>
<p><input type='file' name='uploadfile'>
<input type='submit' name='add' value='Загрузить' ></p>
</form>
<?php
}
?>
</div>

 <h3>Список модулей</h3>
<?php
//Форма со списком модулей, кнопками подключения, отключения и удаления
if(isset($immod))
{foreach($immod as $key=>$value) 
{
?>
<form class="bor" method="POST">
<input class="knopdel" type="submit" name="delud" value="Удалить" >
Имя<input class="two" type="text" name="imjaru" value="<?php echo $immod[$key]['russ'] ?>">
Транслит<input class="two" type="text" name="imjaengav" value="<?php echo $key ?>">
Поз.<input class="one" type="text" name="posicmod" value="<?php echo $immod[$key]['pos']; ?>"><input class="two" type="hidden" name="chvid" value="modul">
<?php
if(file_exists("../common/modulen.txt"))
{
if($immod[$key]['pos']===0)
{
?>
<input class="knop" type="submit" name="podkl" value="ВКЛ ." >
<?php
}
else
{ ?> <input class="knopdel" type="submit" name="otkl" value="ВЫКЛ" ><?php
}}
if(file_exists("set/$key.php"))
{ ?>Настраиваемый  <?php 
}
?> </form>
<?php
}
}
//Проверка на соответствие массива модулей и наличия модулей в папке
if(isset($rov2) && $rov2!==3)
{$raznica=key($raznicaone);
if($rov2===1) echo "Лишний модуль в директории модулей!".$raznica;
if($rov2===2) echo "Лишний модуль в записях!".$raznica;
echo "<form method='POST'>
<input type='hidden' name='rov2' value='$rov2' />
<input type='hidden' name='raznica' value='$raznica' />
<input type='submit' name='isprav' value='Исправить!' />
</form>";
}
?>	
