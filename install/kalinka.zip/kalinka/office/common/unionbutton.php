<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<div class="knop"><h3>Создание или редактирование статьи</h3>
<form class='knop' method='POST' title="Для создания статьи оставить поле 'Имя статьи' незаполненным и нажать кнопку 'Подготовить форму', для редактирования ввести имя статьи в поле 'Имя статьи' и нажать кнопку 'Подготовить форму'">
<input type='text' name='namearticle' value='' placeholder="Имя статьи" /><input type='submit' name="go" value="Подготовить форму" >
</form>
</div> 
