<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
//Переменные
//Главная характеристика контента
if(isset($_GET['unit']))  $unit=addslashes(strip_tags(trim($_GET['unit'])));else {$unit="common";$kat="main.php";}
//Дополнительная характеристика контента
if(isset($unit)) {if(isset($_GET[$unit])) $kat=htmlspecialchars(strip_tags(trim($_GET[$unit])));else $kat="main.php";} 
//Идентификатор статьи
if(isset($_GET['id'])) $id=intval($_GET['id']);else $id=1;
//Общее (common) все загрузки
if(isset($_POST['add'])) $add=htmlspecialchars($_POST['add']);//Кнопка загрузки файлов на сервер
if(isset($_POST['des'])) $des=htmlspecialchars($_POST['des']);//Метка для загрузок
//Наименование модуля на русском при загрузке
if(isset($_POST['imjaruav'])) $imjaruav=htmlspecialchars(strip_tags(trim($_POST['imjaruav'])));
//Служебные переменные при загрузке
if(isset($_POST['prov1'])) $prov1=intval($_POST['prov1']);
//if(isset($_POST['prov2'])) $prov2=intval($_POST['prov2']);
//Загружаемый файл - базовое имя без расширения
if(isset($_POST['uzfile'])) $uzfile=htmlspecialchars(strip_tags(trim($_POST['uzfile'])));
//Полное имя загружаемого файла
if(isset($_POST['uzmod'])) $uzmod=htmlspecialchars(strip_tags(trim($_POST['uzmod'])));
//Характеристика элемента (модуль, шаблон...)
if(isset($_POST['chvid'])) $chvid=htmlspecialchars(strip_tags(trim($_POST['chvid'])));//Характеристика подключаемого файла Служебная переменная
//Модули
//Наименование модуля на русском
if(isset($_POST['imjaru'])) $imjaru=htmlspecialchars(strip_tags(trim($_POST['imjaru'])));
//Позиция модуля
if(isset($_POST['posicmod'])) $posicmod=htmlspecialchars(strip_tags(trim($_POST['posicmod'])));
if(isset($_POST['nomerpos'])) $nomerpos=intval($_POST['nomerpos']);
//Кнопка перехода к настройкам
if(isset($_POST['set'])) $set=htmlspecialchars(strip_tags(trim($_POST['set'])));
//Имя модуля на латинице
if(isset($_POST['imjaengav'])) $imjaengav=htmlspecialchars(strip_tags(trim($_POST['imjaengav'])));
//Переход к файлу настроек модуля
if(isset($set) && isset($imjaengav))
{@header("Location:avpult.php?page=set&set=$imjaengav.php&proven=".$_SESSION['proven']);}
//Разница между созданным массивом и папкой модулей
if(isset($_POST['raznica'])) $raznica=htmlspecialchars(strip_tags(trim($_POST['raznica'])));
//Кнопка исправления ошибок установки модуля
if(isset($_POST['isprav'])) $isprav=htmlspecialchars(strip_tags(trim($_POST['isprav'])));
//Меню
//Название меню 
if(isset($_POST['bok'])) $bok=htmlspecialchars(strip_tags(trim($_POST['bok'])));
//Шаблон отображения
//Название шаблона
if(isset($_POST['tem'])) $tem=htmlspecialchars(strip_tags(trim($_POST['tem'])));
//Звено
//Имя  звена
if(isset($_POST['amod'])) $amod=htmlspecialchars(strip_tags(trim($_POST['amod'])));
//Изображения(картинки)  
//image Кнопка выбора типа узла
if(isset($_POST['radio'])) $radio=htmlspecialchars(strip_tags(trim($_POST['radio'])));//Кнопка выбора узла
//Перевод имени узла для изображений
if(isset($radio))
{switch($radio){
case "common":$newr="Общее"; break;
case "book":$newr="Блог"; break;
case "book1":$newr="Блог1"; break;
case "freeware": $newr="Скачивания";break;
case "shop":$newr="Магазин"; break;
case "payware":$newr="Платные продукты"; break;
}}
//Кнопка удаления image
if(isset($_POST['delizo'])) $delizo=htmlspecialchars(strip_tags(trim($_POST['delizo'])));
//Документы 
if(isset($_POST['radiodocum'])) $radiodocum=htmlspecialchars(strip_tags(trim($_POST['radiodocum'])));//Кнопка выбора узла
if(isset($_POST['buttondoc'])) $buttondoc=htmlspecialchars(strip_tags(trim($_POST['buttondoc'])));//Выбор типа документа
if(isset($_POST['poleosn'])) $poleosn=$_POST['poleosn'];//Основное поле текста
if(isset($_POST['savedocum'])) $savedocum=htmlspecialchars(strip_tags(trim($_POST['savedocum'])));//Сохранение документа
if(isset($_POST['deldocum'])) $deldocum=htmlspecialchars(strip_tags(trim($_POST['deldocum'])));//Удаление документа
//Логотип и название
if(isset($_POST['otpr'])) $otpr=htmlspecialchars(strip_tags(trim($_POST['otpr'])));//Сохранение названия title сайта
if(isset($_POST['savelogot'])) $savelogot=htmlspecialchars(strip_tags(trim($_POST['savelogot'])));//Сохранение логотипа
// новое название
if(isset($_POST['ttl'])) $ttl=htmlspecialchars(stripslashes($_POST['ttl']));
//Кнопка подключения
if(isset($_POST['podkl'])) $podkl=htmlspecialchars(strip_tags(trim($_POST['podkl'])));   
//Кнопка отключения
if(isset($_POST['otkl'])) $otkl=htmlspecialchars(strip_tags(trim($_POST['otkl'])));
//Кнопка удаления модуля, шаблона, меню, звена
if(isset($_POST['delud'])) $delud=htmlspecialchars(strip_tags(trim($_POST['delud'])));
//Кнопка выбора типа узла при удалении 
if(isset($_POST['radiobutton'])) $radiobutton=htmlspecialchars(strip_tags(trim($_POST['radiobutton'])));
//УЗЛЫ Переменные*******************************
if(isset($_POST['namearticle'])) $namearticle=htmlspecialchars(strip_tags(trim($_POST['namearticle'])));//Имя статьи
if(isset($_POST['go'])) $go=htmlspecialchars(strip_tags(trim($_POST['go'])));//Кнопка перехода к созданию или редактированию
if(isset($_POST['save'])) $save=htmlspecialchars(strip_tags(trim($_POST['save'])));//Кнопка сохранения
if(isset($_POST['delst'])) $delst=htmlspecialchars(strip_tags(trim($_POST['delst'])));
if(isset($_POST['part'])) $part=htmlspecialchars(strip_tags(trim($_POST['part'])));//Имя раздела(отдела)
//if(isset($_POST['chapter'])) $chapter=htmlspecialchars(strip_tags(trim($_POST['chapter'])));//Имя главы(секции)
if(isset($_POST['title'])) $title=htmlspecialchars(strip_tags(trim($_POST['title'])));//Имя статьи
if(isset($_POST['keywords'])) $keywords=htmlspecialchars(strip_tags(trim($_POST['keywords'])));//Ключевые слова
if(isset($_POST['annot'])) $annot=htmlspecialchars(strip_tags(trim($_POST['annot'])));//Аннотация
if(isset($_POST['id'])) $id=intval($_POST['id']);
if(isset($_POST['author'])) $author=htmlspecialchars(strip_tags(trim($_POST['author'])));//Автор
if(isset($_POST['mess'])) $mess=$_POST['mess'];//Текст
//if(isset($_POST['oldpart'])) $oldpart=intval($_POST['oldpart']);//Бывшее Ид раздела(отдела)
if(isset($_POST['replpart'])) $replpart=htmlspecialchars(strip_tags(trim($_POST['replpart'])));//Переименовать раздел
if(isset($_POST['redactor'])) $redactor=intval($_POST['redactor']);//Метка
if(isset($_POST['redmag'])) $redmag=intval($_POST['redmag']);//Метка
if(isset($_POST['redfree'])) $redfree=intval($_POST['redfree']);//Метка
if(isset($_POST['listarticle'])) $listarticle=intval($_POST['listarticle']);//Номер сортировки
//Организация контента
if(isset($_POST['picker'])) $picker=$_POST['picker'];
if(isset($_POST['numberpart'])) $numberpart=intval($_POST['numberpart']);
if(isset($_POST['simplearticle'])) $simplearticle=htmlspecialchars(strip_tags(trim($_POST['simplearticle'])));
if(isset($_POST['klarticle'])) $klarticle=htmlspecialchars(strip_tags(trim($_POST['klarticle'])));
if(isset($_POST['costprod'])) $costprod=$_POST['costprod'];//Цена руб
//ОБЩЕЕ************************
//Информация - узлы
$arrblock=array("book"=>"Блог","book1"=>"Блог1","freeware"=>"Скачивания","shop"=>"Магазин","payware"=>"Платные продукты","common"=>"Общие");
//Массив для документов
$arrpravila=array("pravila"=>"Правила","spos"=>"Как приобрести","zajavl"=>"Конфиденциальность","regim"=>"Режим работы");
//Информация - шаблоны. сканирование
if(file_exists("../template"))  
{$shablon=array();
$dr="../template";$skip = array('.', '..');
$sh=scandir($dr);
foreach($sh as $tempe) {if(!in_array($tempe, $skip)) $shablon[]=$tempe;
}clearstatcache();
}
//Информация - меню. сканирование
if(file_exists("../menu"))  
{$shabln=array();$dr="../menu";$skip = array('.', '..');
$sh=scandir($dr);
foreach($sh as $temple) {if(!in_array($temple, $skip)) if($temple!=='topmenu') $mn[]=$temple;
}clearstatcache();
}
//Информация - звено. сканирование
if(file_exists("modul/"))
{ 
$modulust=array();$dr="modul/";$skip=array('.','..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $admmod[]=$shmod;
}clearstatcache();	
}
//Информация - модули. Массив 
if(!file_exists("../common/modulen.txt") && !isset($immod)) {$immod=array("modcreg"=>array("pos"=>6,"russ"=>"Модуль входа",'dopcon'=>0),"mdObr"=>array("pos"=>0,"russ"=>"Обратная связь",'dopcon'=>16));
 touch("../common/modulen.txt");$firstm=serialize($immod);$paq = fopen( "../common/modulen.txt", "w")or die ( "Такой позиции не существует");
{fputs( $paq, "$firstm");
fflush($paq);
fclose( $paq);}@header("Location: ".$_SERVER['HTTP_REFERER']);}
else
{if(file_exists("../common/modulen.txt")) {$ct="../common/modulen.txt";
$fon=fopen($ct, "r");
$immod=unserialize(fread($fon, filesize($ct)));
if(!is_array ($immod)) {
// если что-то прошло не так, инициализировать  массив
$immod=array("modcreg"=>array("pos"=>6,"russ"=>"Модуль входа",'dopcon'=>0),"mdObr"=>array("pos"=>0,"russ"=>"Обратная связь",'dopcon'=>16));
}
fflush($fon);
fclose($fon);clearstatcache();}
}
//Массив позиций действующих модулей
if(isset($immod))
{foreach($immod as $key=>$val)
$posone[$key]=$immod[$key]['pos'];
$pos=array_flip($posone);
}
//Сканирование директории
if(file_exists("../modul"))
{
$modulu=array();$drmod="../modul";$skip=array('.','..');
if(!empty($drmod)) $mdsh = scandir($drmod);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $modulu[]=$shmod;
}clearstatcache();	
}
//Настройки модулей сканирование
if(file_exists("set/"))   
{
$setcont=array();
$dirskan="set/";$skip = array('.', '..');$setcontscan=scandir($dirskan);
foreach($setcontscan as $list) {if(!in_array($list, $skip)) if($list!=="mdObr.php") $setcont[]=basename($list,".php");
}
}
//ОБЩЕЕ сценарии
//Загрузки
if(isset($add)) {
if(isset($_FILES['uploadfile']['name'])) $uzfile=basename($_FILES['uploadfile']['name'],".zip"); $uzmod=basename($_FILES['uploadfile']['name']);
//Предварительная проверка и загрузка
if(!file_exists("../uploads")) mkdir("../uploads");clearstatcache();
//Распаковали загрузочную и удалили архив загрузки
if(isset($uzmod)) if(preg_match("#^(OpL){1}+[a-zA-Z0-9-]{2,128}+(\.)+(zip)+$#i",$uzmod)) $put=22; else {$put=112;}$err=array();
if(isset($put) && $put===22) {$upload='../uploads/';$predvzag=$upload.$uzmod;
if(move_uploaded_file($_FILES['uploadfile']['tmp_name'], $predvzag))
{ 
if(file_exists("$predvzag")) $tupica=new PclZip($predvzag);
if($tupica->extract("../uploads/")==0) {
die("Error:".$tupica->errorInfo(true));
} else 
 {if(isset($predvzag)) unlink($predvzag);
//Нашли имя файла в папке загрузки
if(file_exists("../uploads/$uzfile"))
{//Формируем массив 
$imaskach=array();$dr="../uploads/$uzfile";$skip = array('.', '..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $imaskach[]=$shmod;
}	
}
 
//Распаковали файл для скачивания
$predvscach="../uploads/$uzfile/$imaskach[0]";
if(isset($predvscach)) $secarchive=new PclZip($predvscach);
if ($secarchive->extract("../uploads/")==0) {
die("Error:".$secarchive->errorInfo(true));
} 
else {if(file_exists($predvscach)) {unlink($predvscach);rmdir("../uploads/$uzfile");}
 
if(file_exists("../uploads"))
{//Формируем массив 
$imaskach=array();$dr="../uploads";$skip = array('.', '..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $imafin[]=$shmod;
}	
} 
if(preg_match("/^[a-zA-Z]{2}+(plat){1}+[a-zA-Z]{0,20}+(\.)+(zip)+$/i",$imafin[0]))
$kontrolstring=$imafin[1]; else $kontrolstring=$imafin[0];
if(file_exists("../uploads/$kontrolstring"))
{//Формируем массив 
$imaskach=array();$dr="../uploads/$kontrolstring";$skip = array('.', '..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $imafintw[]=$shmod;
}	
}

//Определяем две первые буквы имени загружаемого файла
if(isset($imafintw) && isset($imafintw[0])) $string=$imafintw[0];$thisstring=$string{0}.$string{1};

$finishload="../uploads/$kontrolstring/$imafintw[0]";
if(copy($finishload, "../uploads/$imafintw[0]")) {unlink($finishload);rmdir("../uploads/$kontrolstring/");
$prov1=2;$uzfile=basename($imafintw[0],".zip");$uzmod=$imafintw[0];$des=$thisstring;}
}
}}}

if(isset($put) && $put===112)
{//Если файл - не изображение, бесплатный, распаковываем 
if(isset($_FILES['uploadfile']['name'])) $uzfile=basename($_FILES['uploadfile']['name'],".zip");$uzmod=basename($_FILES['uploadfile']['name']);$prov1=1; }
$upload='../uploads/'; $predvzag=$upload.$uzmod;
if(move_uploaded_file($_FILES['uploadfile']['tmp_name'], $predvzag))
{ if(file_exists($predvzag)) $tupica=new PclZip($predvzag);
if($tupica->extract("../uploads/") == 0) {
die("Error : ".$tupica->errorInfo(true));
} else {if(isset($predvzag)) unlink($predvzag);
//Нашли имя файла в папке загрузки
if(file_exists("../uploads/$uzfile"))
{//Формируем массив 
$imaskach=array();$dr="../uploads/$uzfile";$skip = array('.', '..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $imaskach[]=$shmod;
}	
}
// Первые буквы имени загружаемого файла
if(isset($imaskach) && isset($imaskach[0])) $string=$imaskach[0];$thisstring=$string{0}.$string{1};$pstring=array("1"=>"md","2"=>"mn","3"=>"tm","4"=>"zv","5"=>"bo","6"=>"fr","7"=>"sh","8"=>"pa",);if(array_search($thisstring,$pstring)) $ok="ok"; else $ok="bad";
if(isset($ok) && $ok==="ok"){
if(copy("../uploads/$uzfile/$string","../uploads/$string")) {unlink("../uploads/$uzfile/$string");rmdir("../uploads/$uzfile");}
if(isset($thisstring)) switch($thisstring) {
case "bo": $des="uzel";
break;
case "fr":$des="uzel";
break;
case "sh":$des="uzel";
break;
case "pa":$des="uzel";
break;
default:$des=$thisstring;
break;
}
$uzfile=basename($string,".zip");$uzmod=$string;
if(isset($thisstring) && isset($uzmod)) if(!preg_match("/^($thisstring)+[a-zA-Z]{1,30}+(\.)+(zip)+$/i", $uzmod)) $err[]="<h3>Эта программа не из той коробки!</h3>";
}
}
}
}
if(isset($des)){
if(isset($des))switch($des) {
case "uzel":if(!file_exists("../uploads/"))  mkdir("../uploads/");clearstatcache();
$uploaddir='../uploads/';//Директория загрузки
//Создаем файл
if(!file_exists("../$uzfile/")) mkdir("../$uzfile/");
//Создаем файл admin
if(!file_exists("$uzfile/")) mkdir("$uzfile/");
//Создаем файл admin menu
if(!file_exists("menu/menu$uzfile")) mkdir("menu/menu$uzfile");
/*if(isset($thisstring) && $thisstring==="fr")
{if(!file_exists("../$uzfile/download")) mkdir("../$uzfile/download");}*/
if(isset($thisstring) && $thisstring==="pa")
{if(!file_exists("../$uzfile/download")) mkdir("../$uzfile/download");}
$uploadfile="../uploads/$uzmod";//Файл загрузки с учетом имени директории загрузки
$ustanov="uzel";//Второе Условие установки(действия после загрузки на сервер - разархивирование и т.п.)
$ustanovka="0";//Первое условие установки(загрузка на сервер
break;
case "md":if(!file_exists("../modul/"))  mkdir("../modul/");clearstatcache();
$uploaddir='../modul/';if(isset($uzmod) && $uploaddir)
$uploadfile="../uploads/$uzmod";
$ustanov="modul";
$ustanovka="0";
//$charact="md";
if(isset($prov1) && $prov1==2) $newk="осуществлениеожидаемогои";
break;
case "zv":if(!file_exists("modul/"))  mkdir("modul/");clearstatcache();if(!file_exists("uploads/"))  mkdir("uploads/");clearstatcache();
$uploaddir='modul/';if(isset($uzmod) && $uzmod!==""  && isset($uploaddir))
{$uploadfile="../uploads/$uzmod";
$ustanov="zveno";//Условие установки
$ustanovka="0";
//$charact="ma";
if(isset($prov1) && $prov1==2) $newk="Знаниеделаетнадменным";
/////////////////////////////////////////////////
}
break;
case "izo":if(!file_exists("../images/"))  mkdir("../images/");clearstatcache();if(!file_exists("../images/$radio"))  mkdir("../images/$radio");clearstatcache();
if(isset($radio)) { $uploaddir="../images/$radio/";//if($radio==="book"){
if(!file_exists("images/")) mkdir("images/");clearstatcache();if(!file_exists("images/$radio"))  mkdir("images/$radio");clearstatcache();//}
}
$ustanov="iz";
$ustanovka="1";
if(isset($_FILES['userfile']['name']) && $_FILES['userfile']['name']!=="") {foreach($_FILES['userfile']['name'] as $k=>$v){
{if (isset($_FILES['userfile']['name'][$k]))
{
$uplo[$k]=basename($v);
$uploadfile[$k]=$uploaddir.$uplo[$k];}}}}
break;
case "tm":if(!file_exists("../template/"))  mkdir("../template/");clearstatcache();
$uploaddir='../template/';
if(isset($uzmod) && $uploaddir)
$uploadfile="../uploads/$uzmod";
$ustanov="template";
$ustanovka="0";
if(isset($prov1) && $prov1===2) $newk="Понимающеесердце";
break;
case "mn":if(!file_exists("../menu/"))  mkdir("../menu/");clearstatcache();
$uploaddir='../menu/';if(isset($uzmod) && $uploaddir)
$uploadfile="../uploads/$uzmod";
$ustanov="md";
$ustanovka="0";
if(isset($prov1) && $prov1==2) $newk="Крепковзятьсяза";
break;
}
}
if(isset($thisstring))
{if(preg_match("/^($thisstring){1}+(plat){1}+[a-zA-Z]{0,20}+(\.)+(zip)+$/i", $uzmod)) $prov1=2;
else $prov1=1;}
if(isset($ustanovka) && $ustanovka==="1")
{if(isset($uploadfile)) foreach($uploadfile as $k=>$v) {
if(move_uploaded_file($_FILES['userfile']['tmp_name'][$k], $uploadfile[$k])){
//if($radio==="book") {
if(file_exists($uploadfile[$k])) copy($uploadfile[$k],"images/$radio/$uplo[$k]");
//}
clearstatcache();
}}
}
else { 
//Имя на соответствие
if(isset($uploaddir) && isset($uzfile)) if(file_exists("$uploaddir/$uzfile")) $err[]="<h3>Файл с таким именем уже существует!</h3>";
if(isset($err)) $count=count($err);if(isset($count) && $count!==0)
// Копируем файл из каталога для временного хранения файлов:
{
//При наличии ошибок установка прерывается и выводятся ошибки
if(isset($err))
foreach($err as $key=>$error)
echo $error;
}
}
if(isset($ustanov)) {
switch($ustanov) {
case "iz":@header("Location: ".$_SERVER['HTTP_REFERER']);
break;
case "uzel":
if(isset($uzfile) && isset($arrblock[$uzfile])) {
if($uzfile==="shop") {$mysqli->query("SET NAMES 'utf8'");
if(!$mysqli->query("CREATE TABLE IF NOT EXISTS assortment(
id int (10),
kodproduct int(10),
cost decimal(9,2),
PRIMARY KEY (id)) COMMENT='Ассортимент $arrblock[$uzfile]'")) {
echo "Не удалось создать таблицу Ассортимент $arrblock[$uzfile]: (".$mysqli->errno.")".$mysqli->error;
}
$mysqli->query("SET NAMES 'utf8'");
if(!$mysqli->query("CREATE TABLE IF NOT EXISTS accounting(
id int(10),
saldo int(10),
debet int(10),
kredit int(10),
month varchar(128),
PRIMARY KEY (id)) COMMENT='Учет $arrblock[$uzfile]'")) {
echo "Не удалось создать таблицу Учет $arrblock[$uzfile]: (".$mysqli->errno.")".$mysqli->error;
}
}
if($uzfile==="payware") {$mysqli->query("SET NAMES 'utf8'");
if(!$mysqli->query("CREATE TABLE IF NOT EXISTS passortment(
id int (10),
title varchar(255),
cost decimal(9,2),
download int(10),
PRIMARY KEY (id)) COMMENT='Ассортимент $arrforblock[$uzfile]'")) {
echo "Не удалось создать таблицу Ассортимент $arrforblock[$uzfile]: (".$mysqli->errno.")".$mysqli->error;
}
}
$mysqli->query("SET NAMES 'utf8'");
if (!$mysqli->query("CREATE TABLE IF NOT EXISTS $uzfile(
id int (10) AUTO_INCREMENT,
title varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
list int (20),
content text CHARACTER SET utf8 COLLATE utf8_general_ci,
author varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci,
dat date,
keywords varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci,
annotation text CHARACTER SET utf8 COLLATE utf8_general_ci,
idpart int (10),
idchapter int (10),
PRIMARY KEY (id)) COMMENT='Тексты статей узла $arrblock[$uzfile]'")) {
    echo "Не удалось создать таблицу $arrblock[$uzfile]: (" . $mysqli->errno . ") " . $mysqli->error;
}
//else echo "Таблица Блог1 успешно создана";
 $resu=$mysqli->query("SELECT content FROM $uzfile WHERE id='1'");
 $prov=$resu->fetch_array();
if(empty($prov['content']))
{$mysqli->query("SET NAMES 'utf8'");
if (!$mysqli->query("INSERT INTO $uzfile(
title,list,content,author,keywords,annotation,idpart,idchapter)
VALUES('$arrblock[$uzfile]','0','Приветствую Вас на главной странице узла $arrblock[$uzfile]!','admin','.','.','0','0')")) 
{echo "Не удалось ввести данные в $uzfile: (".$mysqli->errno . ")".$mysqli->error;}
//else echo "Данные введены в таблицу Блог1!";
}
else echo "Данные уже введены в таблицу $uzfile!";
$newcomment="feedback".$uzfile;
$mysqli->query("SET NAMES 'utf8'");
if(!$mysqli->query("CREATE TABLE IF NOT EXISTS $newcomment(
id int (10) AUTO_INCREMENT,
comment text CHARACTER SET utf8 COLLATE utf8_general_ci,
namecostomer varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci,
email varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci,
idarticle int(10),
namearticle varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci,
dat date,
moder tinyint(4),
PRIMARY KEY (id)) COMMENT='Комментарии к статьям узла $arrblock[$uzfile]'")) {
echo "Не удалось создать таблицу $arrblock[$uzfile]: (".$mysqli->errno.")".$mysqli->error;
}
$newpart="part".$uzfile;
$mysqli->query("SET NAMES 'utf8'");
if (!$mysqli->query("CREATE TABLE IF NOT EXISTS $newpart(
id int (10) AUTO_INCREMENT,
title varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci,
PRIMARY KEY (id)) COMMENT='Разделы узла $arrblock[$uzfile]'")) {
echo "Не удалось создать таблицу $arrblock[$uzfile]: (".$mysqli->errno.")" . $mysqli->error;
}
}
if (isset($uploaddir))
{//создаем новый объект ZipArchive 
if(isset($uploadfile)) $tharchive=new PclZip("$uploadfile");
if ($tharchive->extract($uploaddir) == 0) {
die("Error : ".$tharchive->errorInfo(true));
}
}
//После того, как распакован архив на сервере
if(file_exists("../uploads/$uzfile/top.php")) if(copy("../uploads/$uzfile/top.php", "../$uzfile/top.php")) unlink("../uploads/$uzfile/top.php");clearstatcache();
switch($uzfile)
{//Устанавливаем************************************************************
case 'freeware':
if(file_exists("../uploads/freeware/download"))  
{if(!file_exists("../freeware/download")) mkdir("../freeware/download");
if (file_exists("$uploaddir/freeware/download/freeware.php")) 
{if(copy("../uploads/freeware/download/freeware.php", "../freeware/download/freeware.php"))
unlink("../uploads/freeware/download/freeware.php");clearstatcache();
if (file_exists("$uploaddir/freeware/download/")) 
{
rmdir("$uploaddir/freeware/download/");clearstatcache();
}
}if(copy("../uploads/freeware/freeload.php", "../freeware/freeload.php"))
unlink("../uploads/freeware/freeload.php");clearstatcache();
}
break;
}
//****ПАПКА МЕНЮ АДМИН
if(file_exists("$uploaddir/$uzfile/menu/menu/"))
{ $uzmn=array();$drm="$uploaddir/$uzfile/menu/menu/";$skip=array('.', '..');$uzmen=scandir($drm);
foreach($uzmen as $el) {
if(!in_array($el, $skip)) $uzmn[]=$el;}	
}
if(isset($uzmn))
{foreach($uzmn as $val)
//Копируем остальные файлы в созданную папку
{if (file_exists("$uploaddir/$uzfile/menu/menu/$val")) 
{if (copy("$uploaddir/$uzfile/menu/menu/$val", "menu/menu$uzfile/$val"))
unlink("$uploaddir/$uzfile/menu/menu/$val");clearstatcache();
if (!file_exists("$uploaddir/$uzfile/menu/menu/$val")) 
{rmdir("$uploaddir/$uzfile/menu/menu/");clearstatcache();}
}
}
}
if (file_exists("$uploaddir/$uzfile/menu/"))
{rmdir("$uploaddir/$uzfile/menu/");clearstatcache();}
//****СТАРШИЙ ФАЙЛ ОТОБРАЖЕНИЯ БЛОКА
if (file_exists("$uploaddir/$uzfile/main$uzfile.php"))
{if (copy("$uploaddir/$uzfile/main$uzfile.php", "../main$uzfile.php"))
{if (unlink("$uploaddir/$uzfile/main$uzfile.php")) clearstatcache();}
}
//****ПАПКА АДМИНКИ БЛОКА
if (file_exists("$uploaddir/$uzfile/$uzfile"))
{$uz=array();$dr="$uploaddir/$uzfile/$uzfile";
$skip = array('.', '..');$uzsh = scandir($dr);
foreach($uzsh as $el) {
if(!in_array($el, $skip)) $uz[]=$el;}	
}
if(isset($uz))
{foreach($uz as $val)
{ //Копируем остальные файлы в созданную папку
{if (file_exists("$uploaddir/$uzfile/$uzfile/$val")) 
{if (copy("$uploaddir/$uzfile/$uzfile/$val", "$uzfile/$val"))
{unlink("$uploaddir/$uzfile/$uzfile/$val");clearstatcache();}
}
}
}
if (file_exists("$uploaddir/$uzfile/$uzfile/")) 
{rmdir("$uploaddir/$uzfile/$uzfile/");clearstatcache();}
}
if(isset($uzfile))
if(file_exists("$uzfile/") &&
file_exists("../main$uzfile.php") && file_exists("../$uzfile/") ) 
{if (rmdir("$uploaddir/$uzfile")) clearstatcache(); 
if (unlink("$uploadfile"))
{clearstatcache(); @header("Location: ".$_SERVER['HTTP_REFERER']);} 
else echo "Ошибка при установке узла"; 
}
break;
default:
{if(isset($uploaddir))
{//создаем новый объект ZipArchive
if(isset($uploadfile)) $foarchive=new PclZip($uploadfile);
if ($foarchive->extract($uploaddir) == 0) {
die("Error : ".$foarchive->errorInfo(true));
}
}} 
//Удалить загруженные файлы из папки uploads
if(file_exists("$uploaddir/$uzfile/key.php"))
{
include_once "$uploaddir/$uzfile/key.php";
//Создаем рабочий ключ
if(isset($prov1) && $prov1===2)
{if(isset($newnewkey) && $newnewkey==="OK")
{$f1="$"."keyust";
if(!file_exists("$uploaddir/$uzfile/newkey.php"))  
touch("$uploaddir/$uzfile/newkey.php",755);
{$pd = fopen( "$uploaddir/$uzfile/newkey.php", "wb")or die ( ". Такой позиции не существует" );
flock( $pd, 2 ); // Полная блокировка
fputs( $pd, "<?php if(!defined('BUGIT')) exit ('Ошибка соединения');$f1='$ewkey'; ?>");
fflush($pd);
flock( $pd, 3 ); // Снятие блокировки
fclose( $pd);}
if (file_exists("$uploaddir/$uzfile/key.php"))
unlink("$uploaddir/$uzfile/key.php");
}
else die("Нет ключа");
}
}
if (isset($uploaddir) && $uploaddir==="../modul/") {
//При наличии дополнительной функциональности - загружаем файл настроек в папку настроек
if (file_exists("$uploaddir/$uzfile/$uzfile.php"))
{if (!file_exists("set"))
mkdir("set");
if (copy("$uploaddir/$uzfile/$uzfile.php", "set/$uzfile.php"))
unlink("$uploaddir/$uzfile/$uzfile.php"); 
}
//Для модуля постоянного подключения извлекаем позицию подключения
if (file_exists("$uploaddir/$uzfile/kon.php"))
{include_once("$uploaddir/$uzfile/kon.php");//$const=$con;
}
//Для переменного - задаем позиции значение 0
else $conwith=0;
//Добавляем данные в массив модулей и сохраняем массив 
if(isset($immod))
{$immod[$uzfile]=array('pos'=>0,'russ'=>$imjaruav,'dopcon'=>$conwith);
if(isset($immod)) $vsul=serialize($immod);
$ps=fopen( "../common/modulen.txt", "w")or die ( "Такой позиции не существует");
{fputs( $ps, "$vsul");
fflush($ps);
fclose( $ps);}
//Удаляем вспомогательный файл с позицией модуля, если он есть
if(file_exists("$uploaddir/$uzfile/kon.php"))
unlink("$uploaddir/$uzfile/kon.php");
}}
//Удаляем предварительный файл загрузки
if(file_exists($uploadfile))
{
if(unlink("$uploadfile"))
{if(isset($_FILES)) unset($_FILES);@header("Location: ".$_SERVER['HTTP_REFERER']);if(isset($uzfile)) unset($uzfile);if(isset($add)) unset($add);if(isset($des)) unset($des);
clearstatcache();} 
else
echo "Ошибка при удалении файла из папки загрузок";}
break;
}
}
//УДАЛЕНИЯ сценарии
/*Удаление модуля, шаблона, звена, меню*/
if(isset($delud))
{//Проверяем что удаляем, проверяем подключение, рекомендуем отключить $recomend
if(isset($chvid)){
//Если это модуль, удаляем из списка модулей и перезаписываем, если шаблон, удаляем папку макета
switch($chvid){
case "template":if(isset($tem)) {if(file_exists("../variables/vartempl.php")) {include_once "../variables/vartempl.php";
} if($osnova===$tem) {$recomend="YES";die("Пожалуйста, подключите сначала другой шаблон, после чего переходите к удалению. <a href='$_SERVER[HTTP_REFERER]'>Вернуться</a>");}
else {if(file_exists("../template/$tem/maket/"))
{$kb = "../template/$tem/maket";
//Открываем папку
$dkb = opendir($kb) or die("Не удалось открыть каталог $c");
//В цикле читаем
while(FALSE!==($opb=readdir($dkb))){if($opb!= "." && $opb != "..") unlink("$kb/$opb");}
closedir($dkb);rmdir("../template/$tem/maket");
} 
} $mytem=$tem;$dirdel="../template";
}
break;
case "modul":if(isset($imjaengav)) {if($imjaengav==='modcreg') die ("Модуль не подлежит удалению!".$immod[$imjaengav]["russ"]);
else {if(isset($immod))if(isset($immod[$imjaengav])) unset($immod[$imjaengav]);
//Сохраняем массив
$vsul=serialize($immod);}
if (file_exists("set/$imjaengav.php"))
{//Удаляем настройки модуля,если они существуют
if (unlink("set/$imjaengav.php"))
{if (file_exists("../common/mml.php")) unlink("../common/mml.php");
}
}
$mytem=$imjaengav;$dirdel="../modul";
}
break;
case "zveno": if(isset($amod)) $mytem=$amod;$dirdel="modul";
break;
case "menu": if(isset($bok)){if($bok==="menusimple") die("Это меню не подлежит удалению. <a href='$_SERVER[HTTP_REFERER]'>Вернуться</a>");
else {$mytem=$bok;$dirdel="../menu";}}
break;
}}
//Сканируем и удаляем файлы указанной директории
if(isset($mytem) && isset($dirdel))
{if (file_exists("$dirdel/$mytem"))
//Открываем каталог
//Формируем массив 
$zvdeleate=array();$dr="$dirdel/$mytem";$skip=array('.','..');
if(!empty($dr)) $mdsh = scandir($dr);
foreach($mdsh as $shmod) {if(!in_array($shmod, $skip)) $zvdeleate[]=$shmod;
}clearstatcache();
if(isset($zvdeleate)) {foreach($zvdeleate as $key=>$val) unlink("$dirdel/$mytem/$val");}
if(rmdir("$dirdel/$mytem"))
{clearstatcache();if(isset($dirdel)) unset($dirdel);if(isset($mytem)) unset($mytem);if(isset($chvid)) unset($chvid);
if(isset($delud)) unset($delud);@header("Location: ".$_SERVER['HTTP_REFERER']);
}
else echo "Ошибка удаления $mytem";
} 
}
//Удаление узла
if(isset($radiobutton)){ echo $deluzel=$radiobutton;
//Если выбран узел для удаления
if (isset($deluzel))
{if(file_exists("../$deluzel"))
{//Создаем папки 
if (!file_exists("../uploads/$deluzel/")) mkdir("../uploads/$deluzel/");
if (!file_exists("../uploads/$deluzel/$deluzel/")) mkdir("../uploads/$deluzel/$deluzel/");
}
// для тех блоков, где они есть
switch($deluzel)
{
case 'book1':
//Удаляем статьи из БД
$query1="DELETE LOW_PRIORITY  QUICK FROM book1";
$result1=$mysqli->query($query1);
if($result1==true) {
$query2="DROP TABLE book1";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены статьи!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one1="DELETE LOW_PRIORITY  QUICK FROM feedbackbook1";
$result_one1=$mysqli->query($query_one1);
if($result_one1==true) {
$query2="DROP TABLE feedbackbook1";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены комментарии!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
/*$query_th="DELETE LOW_PRIORITY  QUICK FROM chapterbook";
$result_th=$mysqli->query($query_th);
if($result_th==true) echo "Удалены главы!";
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;*/
$query_two1="DELETE LOW_PRIORITY  QUICK FROM partbook1";
$result_two1=$mysqli->query($query_two1);
if($result_two1==true) {$query2="DROP TABLE partbook1";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены разделы!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;

break;
case 'freeware':
if(is_dir("../$deluzel/download/"))
{ $uzzagrone=array();$drz="../$deluzel/download/";
$skip = array('.', '..');$uzzg = scandir($drz);
foreach($uzzg as $el) {
if(!in_array($el, $skip)) $uzzagrone[]=$el;
}	
}
if(isset($uzzagrone))
{foreach($uzzagrone as $val)
//Копируем остальные файлы в созданную папку
{if (file_exists("../$deluzel/download/$val")) 
{if (copy("../$deluzel/download/$val", "../uploads/$deluzel/$val"))
unlink("../$deluzel/download/$val");
}
}
rmdir("../$deluzel/download/");clearstatcache();
}
//Удаляем каталог из БД
$query="DELETE LOW_PRIORITY  QUICK FROM freeware";
$result=$mysqli->query($query);
if($result==true) {
$query2="DROP TABLE freeware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удален каталог!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
/*$query_one="DELETE LOW_PRIORITY  QUICK FROM chapterfreeware";
$result_one=$mysqli->query($query_one);
if($result_one==true) echo "Удалены секции!";
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;*/
$query_two="DELETE LOW_PRIORITY  QUICK FROM partfreeware";
$result_two=$mysqli->query($query_two);
if($result_two==true) {$query2="DROP TABLE partfreeware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены отделы!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one1="DELETE LOW_PRIORITY  QUICK FROM feedbackfreeware";
$result_one1=$mysqli->query($query_one1);
if($result_one1==true) {$query2="DROP TABLE feedbackfreeware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены комментарии!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
break;
case 'shop':
if(is_dir("../korzina/korzinashop") || is_dir("../korzina/modValut") || is_dir("kniga"))
die("<h3>Сначала требуется удалить установленные компоненты!</h3>");
if(is_dir("../$deluzel/res")) rmdir("../$deluzel/res");
if(is_dir("../$deluzel/respredv")) rmdir("../$deluzel/respredv");
//Удаляем каталог из БД
$query="DELETE LOW_PRIORITY QUICK FROM shop";
$result=$mysqli->query($query);
if($result==true) {$query2="DROP TABLE shop";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удален каталог!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one2="DELETE LOW_PRIORITY  QUICK FROM assortment";
$result_one2=$mysqli->query($query_one2);
if($result_one2==true) echo "Удален assortment!";
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one="DELETE LOW_PRIORITY  QUICK FROM accounting";
$result_one=$mysqli->query($query_one);
if($result_one==true) echo "Удален accounting!";
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_two="DELETE LOW_PRIORITY  QUICK FROM partshop";
$result_two=$mysqli->query($query_two);
if($result_two==true) {$query2="DROP TABLE partshop";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены отделы!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one1="DELETE LOW_PRIORITY  QUICK FROM feedbackshop";
$result_one1=$mysqli->query($query_one1);
if($result_one1==true) {$query2="DROP TABLE feedbackshop";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены комментарии!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
break;
case 'payware':
if(is_dir("../basket/basketshop") || is_dir("../basket/modValut") || is_dir("kniga"))
die("<h3>Сначала требуется удалить установленные компоненты!</h3>");
if(is_dir("../$deluzel/res")) rmdir("../$deluzel/res");
if(is_dir("../$deluzel/respredv")) rmdir("../$deluzel/respredv");
if(is_dir("../$deluzel/download/"))
{ $uzzagrone=array();$drz="../$deluzel/download/";
$skip = array('.', '..');$uzzg = scandir($drz);
foreach($uzzg as $el) {
if(!in_array($el, $skip)) $uzzagrone[]=$el;
}	
}
if(isset($uzzagrone))
{foreach($uzzagrone as $val)
//Копируем остальные файлы в созданную папку
{if (file_exists("../$deluzel/download/$val")) 
{if (copy("../$deluzel/download/$val", "../uploads/$deluzel/$val"))
unlink("../$deluzel/download/$val");
}
}
rmdir("../$deluzel/download/");clearstatcache();
}
//Удаляем каталог из БД
$query="DELETE LOW_PRIORITY QUICK FROM payware";
$result=$mysqli->query($query);
if($result==true) {$query2="DROP TABLE payware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удален каталог!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one="DELETE LOW_PRIORITY  QUICK FROM passortment";
$result_one=$mysqli->query($query_one);
if($result_one==true) echo "Удален passortment!";
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_two="DELETE LOW_PRIORITY  QUICK FROM partpayware";
$result_two=$mysqli->query($query_two);
if($result_two==true) {$query2="DROP TABLE partpayware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены отделы!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
$query_one1="DELETE LOW_PRIORITY  QUICK FROM feedbackpayware";
$result_one1=$mysqli->query($query_one1);
if($result_one1==true) {$query2="DROP TABLE feedbackpayware";$result2=$mysqli->query($query2);
if($result2==true) {echo "Удалены комментарии!";} else
echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
}
else echo "Ошибка!<br>(".$mysqli->errno.")".$mysqli->error;
break;
}

if(file_exists("../uploads/$deluzel/$deluzel/")) 
{ if(file_exists("menu/menu$deluzel/")) 
//Открыть и прочитать папку меню узла
{ $uzadmmn=array();$drmn="menu/menu$deluzel/";
$skip = array('.', '..');$uzam = scandir($drmn);
foreach($uzam as $el) {
if(!in_array($el, $skip)) $uzadmmn[]=$el;
}	
}
//Копировать файлы из папки меню админа узла
if(isset($uzadmmn))
{foreach($uzadmmn as $val)
//Копируем остальные файлы в созданную папку
{if (file_exists("menu/menu$deluzel/$val")) 
{if (copy("menu/menu$deluzel/$val", "../uploads/$deluzel/$deluzel/$val")) unlink("menu/menu$deluzel/$val");
}clearstatcache();
}
rmdir("menu/menu$deluzel/");clearstatcache();
}
}
if (file_exists("$deluzel/")) 
//Открыть и прочитать папку admin узла
{ $uzadm=array();$drmn="$deluzel/";
$skip = array('.', '..');$uzam = scandir($drmn);
foreach($uzam as $el) {
if(!in_array($el, $skip)) $uzadm[]=$el;
}	
}
//Копировать файлы из папки меню админа узла
if(isset($uzadm))
{foreach($uzadm as $val)
//Копируем остальные файлы в созданную папку
{if (file_exists("$deluzel/$val")) 
if(copy("$deluzel/$val", "../uploads/$deluzel/$deluzel/$val"))
unlink("$deluzel/$val");
}
if(rmdir("$deluzel/")) clearstatcache();
}
if (file_exists("../$deluzel/")) 
//Открыть и прочитать корневую папку узла
{ $uzuz=array();$drmn="../$deluzel/";
$skip = array('.', '..');$uzam = scandir($drmn);
foreach($uzam as $el) {
if(!in_array($el, $skip)) $uzuz[]=$el;
}	
}
//Копировать файлы из корневой папки меню узла
if(isset($uzuz))
foreach($uzuz as $val)
//Копируем остальные файлы в созданную папку
{if (is_file("../$deluzel/$val")) 
{unlink("../$deluzel/$val");clearstatcache();}
if(is_dir("../$deluzel/$val"))
{ $dh = opendir("../$deluzel/$val");
if(isset($dh))
while (FALSE!==($filename=readdir($dh)))
unlink("../$deluzel/$val/$filename");
closedir("../$deluzel/$val/");rmdir("../$deluzel/$val/");clearstatcache();
}
}
if (is_dir("../$deluzel/"))
{rmdir("../$deluzel/");clearstatcache();}
if (file_exists("../main$deluzel.php")) 
copy("../main$deluzel.php", "../uploads/$deluzel/main$deluzel.php");
if (unlink("../main$deluzel.php")) clearstatcache();
if (is_dir("../uploads/$deluzel/$deluzel/"))
{ $uzdeltwo=array();$drz="../uploads/$deluzel/$deluzel/";
$skip = array('.', '..');$uzzg = scandir($drz);
foreach($uzzg as $el) {if(!in_array($el, $skip))
$uzdeltwo[]=$el;
}	
}
if(is_dir("../uploads/$deluzel/$deluzel/"))
//Удаляем файлы из папки загрузки
{foreach($uzdeltwo as $val)
{if (file_exists("../uploads/$deluzel/$deluzel/$val")) 
unlink("../uploads/$deluzel/$deluzel/$val");clearstatcache();
}}
if(rmdir("../uploads/$deluzel/$deluzel/"))
clearstatcache();
if (is_dir("../uploads/$deluzel/"))
{ $uzdel=array();$drz="../uploads/$deluzel/";
$skip = array('.', '..');$uzzg = scandir($drz);
foreach($uzzg as $el) {
if(!in_array($el, $skip)) $uzdel[]=$el;
}	
}
if(file_exists("../uploads/$deluzel/"))
{foreach($uzdel as $val)
//Удаляем файлы 
{if (file_exists("../uploads/$deluzel/$val")) 
{unlink("../uploads/$deluzel/$val");clearstatcache();}
}
if(rmdir("../uploads/$deluzel/"))
{echo "<h3>Узел $deluzel удален</h3>";
if(isset($deluzel)) unset($deluzel);clearstatcache();}
else echo "Ошибка при удалении"; 
}
}}
//Документы, сохранение и удаление
if(isset($savedocum)){if(isset($radiodocum) && isset($buttondoc) && isset($poleosn))//правила
{if(!file_exists("../$radiodocum/$buttondoc.php")) touch("../$radiodocum/$buttondoc.php");
//Вносим текст 
if(file_exists("../$radiodocum/$buttondoc.php"))//Если есть файл  открываем его и вписываем данные
 //Сохраняем
{$fpm=fopen("../$radiodocum/$buttondoc.php", "w+")or die( "Такой позиции не существует");
fputs( $fpm, "<meta charset='utf-8'/><?php echo '$poleosn';?>");
fflush($fpm);
fclose( $fpm );
}
else echo "Ошибка сохранения";
}
}
if(isset($deldocum)) {if(isset($radiodocum) && isset($buttondoc)){
if(file_exists("../$radiodocum/$buttondoc.php")) unlink("../$radiodocum/$buttondoc.php");
}}
//Удаление изображений
if(isset($delizo)){if(isset($radio)) {unlink("../images/$radio/$delizo");unset($radio);unset($delizo);header("Location: avpult.php?page=common&common=izo.php");}}
//ЛОГОТИП И НАЗВАНИЕ
//Изменяем название сайта
if(isset($otpr))
{//Сохраняем новое название
$f2="$"."heading";if(!file_exists("../variables/variables.php"))
touch('../variables/variables.php');if(file_exists("../variables/variables.php")) {
$fp = fopen( "../variables/variables.php", "w+")or die ( "Не удалось открыть файл" );
fputs( $fp, "<?php if(!defined('BUGIT')) exit ('Ошибка соединения'); $f2='$ttl' ?>");
fclose( $fp );
@header("Location: ".$_SERVER['HTTP_REFERER']); 
}else echo "Ошибка установки";
}
if (isset($savelogot))
{// Загружаем новый логотип
$uploaddir = '../images/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
$name=$_FILES['userfile']['name'];
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile))
{$f1="$"."logotype";
 //Сохраняем его имя  
if (touch('../variables/logotype.php'))
$fp = fopen( "../variables/logotype.php", "w+")or die ( "Не удалось открыть файл" );
fputs( $fp, "<?php if (!defined('BUGIT')) exit ('Ошибка соединения'); $f1='$name' ?>");
fclose( $fp );
if (file_exists("../variables/logotype.php")) @header("Location: ".$_SERVER['HTTP_REFERER']); 
else echo "Ошибка установки логотипа";
} 
else echo "Ошибка загрузки!\n";
}
//ПОДКЛЮЧЕНИЯ, ОТКЛЮЧЕНИЯ
//Подключение
if(isset($podkl)) {
if(isset($chvid)) switch($chvid) { 
case "modul"://Подключаем - вводим в массив позицию модуля
//Номер позиции модуля
if(isset($immod) && isset($imjaengav)) if($immod[$imjaengav]["dopcon"]!==0) $nomerpos=$immod[$imjaengav]["dopcon"];
if(isset($nomerpos))
{if(isset($imjaengav) && isset($immod)) {$immod[$imjaengav]["pos"]=$nomerpos;
$vsul=serialize($immod);}
clearstatcache();
}
break;
case "template":if(isset($tem)) {$filename="$"."osnova";
// Каталог, в который мы будем принимать файл:
if(!file_exists("../variables/")) mkdir ("../variables/");
if(!file_exists("../variables/vartempl.php")) touch('../variables/vartempl.php');
$fp = fopen( "../variables/vartempl.php", "w+")or die ("Не удалось открыть файл");
fputs($fp, "<?php if(!defined('BUGIT'))
exit ('Ошибка соединения'); $filename='$tem'; ?>");
fclose( $fp );if(isset($podkl)) unset($podkl);header("Location: ".$_SERVER['HTTP_REFERER']);
clearstatcache();
}
break;
case "menu":if(isset($bok)) {
//Подключение меню
$filename="$"."menusd";
$fp = fopen( "../variables/menusd.php", "w+")or die ( "Не удалось открыть файл" );
fputs($fp, "<?php if(!defined('BUGIT')) exit('Ошибка соединения'); $filename='$bok'; ?>");
fclose( $fp );
if (file_exists("../variables/menusd.php"))
@header("Location: avpult.php?page=common&common=mn.php");
}
break;
}
}
//-отключение
if(isset($otkl)) {if(isset($chvid)) switch($chvid) {
case "modul":
$immod[$imjaengav]["pos"]=0;$vsul=serialize($immod);
break;
case "menu":
if(isset($bok))
{if (file_exists("../variables/menusd.php"))
unlink("../variables/menusd.php");clearstatcache();
@header("Location: avpult.php?page=common&common=mn.php");
}
break;
}
}
//Массив модулей сохранение
if(isset($vsul)) {
//if(!file_exists("../common/modulen.txt")) touch("../common/modulen.txt"); else
{$ps = fopen( "../common/modulen.txt", "w")or die ( "Такой позиции не существует");
{fputs( $ps, "$vsul");
fflush($ps);
fclose( $ps);}@header("Location:avpult.php?page=common&common=formod.php ");
} 
}
//УЗЛЫ - БД
//Переменные имен таблиц БД
if(isset($unit) && $unit!=="common" && $unit!=="set") {if(file_exists($unit))  {
$maintable=$unit;
$parttable="part".$unit;
$chaptertable="chapter".$unit;
}
//Проверка записей в таблице Статьи*************************
$mysqli->query("SET NAMES 'utf8'");
if($articfirst=$mysqli->query("SELECT id FROM $maintable"))  {$num=$articfirst->num_rows; if(isset($num) && $num>0) $idartic="YES";} else {$idartic="No";}if($articfirst) $articfirst->close();
// проверка на наличие разделов********************
if($partfirst=$mysqli->query("SELECT id FROM $parttable"))  {$num=$partfirst->num_rows; if(isset($num) && $num>0) $idfirst="YES";} else {$idfirst="No";}if($partfirst) $partfirst->close();
//Проверка записей в таблице Главы************************
/*if($chaptfirst=$mysqli->query("SELECT id FROM $chaptertable"))  {$num=$chaptfirst->num_rows; if(isset($num) && $num>0) $idsnd="YES";} else {$idsnd="No";}if($chaptfirst) $chaptfirst->close();*/
//Подготовленные выражения
//********************!!!!!!!!!!!!!!!!!!!
//Разделы
$query="UPDATE $parttable SET title=? WHERE id=?";
$strazdel=$mysqli->prepare($query);
$strazdel->bind_param('si',$mqrazdel,$mqoldrazdel);
$insertrazd=$mysqli->prepare("INSERT INTO $parttable (title) VALUES (?)");
$insertrazd->bind_param('s',$nmn);
//-------------------------------
$mysqli->query("SET NAMES 'utf8'");
$insertarticl=$mysqli->prepare("INSERT INTO $maintable (title,content,author,dat,keywords,annotation,idpart,idchapter) VALUES (?,?,?,?,?,?,?,?)");
$insertarticl->bind_param('ssssssii',$tit,$mss,$avt,$dt,$kw,$antc,$idrz,$newidgl);
//---------------------------------------
$mysqli->query("SET NAMES 'utf8'");
$updarticle=$mysqli->prepare("UPDATE $maintable SET list=? WHERE id=?");
$updarticle->bind_param('ii',$upspartcl,$upidartcl);

//------------------------------------
$mysqli->query("SET NAMES 'utf8'");
$upallarticl=$mysqli->prepare("UPDATE $maintable SET title=?,list=?,content=?,author=?,dat=?,keywords=?,annotation=?,idpart=?,idchapter=? WHERE id=?");
$upallarticl->bind_param('sisssssiii',$tit,$upspartcl,$mss,$avt,$dt,$kw,$antc,$idrz,$newidgl,$totid);
//Организация контента
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
$insertpart=$mysqli->prepare("UPDATE $maintable SET idpart=?,list=? WHERE id=?");
$insertpart->bind_param('iii',$bdidpart,$bdlistart,$bdidarticle);
$updarticlesimple=$mysqli->prepare("UPDATE $maintable SET idpart=? WHERE id=?");
$updarticlesimple->bind_param('ii',$upspartclsimpl,$upidartclsimpl);
//Переименование ключевой статьи
$uptitlearticl=$mysqli->prepare("UPDATE $maintable SET title=? WHERE id=?");
$uptitlearticl->bind_param('si',$titl,$titid);
//----------------------------------------
if(isset($unit) && $unit==="payware")
{$mysqli->query("SET NAMES 'utf8'");
if($assfirst=$mysqli->query("SELECT id FROM passortment LIMIT1"))  {$numass=$assfirst->num_rows; if(isset($numass) && $numass>0) $idcostassort="YES";} else {$idcostassort="No";}if($assfirst) $assfirst->close();
$mysqli->query("SET NAMES 'utf8'");
$insertass=$mysqli->prepare("INSERT INTO passortment (id,title,cost,download) VALUES (?,?,?,?)");
$insertass->bind_param('isdi',$idass,$titass,$cst,$loadass);
$updass=$mysqli->prepare("UPDATE passortment SET title=? WHERE id=?");
$updass->bind_param('si',$upass,$upidass);
$updcst=$mysqli->prepare("UPDATE passortment SET cost=? WHERE id=?");
$updcst->bind_param('di',$upcst,$upidcst);
$updload=$mysqli->prepare("UPDATE passortment SET download=? WHERE id=?");
$updload->bind_param('ii',$uprash,$upidrash);
//select assortment-------------------------------
$mysqli->query("SET NAMES 'utf8'");
if(isset($idcostassort) && $idcostassort==="YES") {
$mysqli->query("SET NAMES 'utf8'");
if($selallassort=$mysqli->prepare("SELECT id,title,cost,download FROM passortment WHERE id>1")) {
$selallassort->execute(); 
$selallassort->bind_result($idassort,$titleassort,$cstassort,$loadassort); 
while($selallassort->fetch()){
$allassort[$idassort]=$titleassort;$assortcost[$idassort]=$cstassort;$assortload[$idassort]=$loadassort;
} if(isset($selallassort)) $selallassort->close();}
}
}
//----------------------------------------
if(isset($unit) && $unit==="shop")
{$mysqli->query("SET NAMES 'utf8'");
if($assfirst=$mysqli->query("SELECT id FROM assortment LIMIT1"))  {$numass=$assfirst->num_rows; if(isset($numass) && $numass>0) $idcostassort="YES";} else {$idcostassort="No";}if($assfirst) $assfirst->close();
$mysqli->query("SET NAMES 'utf8'");
$insertass=$mysqli->prepare("INSERT INTO assortment (id,title,cost) VALUES (?,?,?)");
$insertass->bind_param('isd',$idass,$titass,$cst);
$updass=$mysqli->prepare("UPDATE assortment SET title=? WHERE id=?");
$updass->bind_param('si',$upass,$upidass);
$updcst=$mysqli->prepare("UPDATE assortment SET cost=? WHERE id=?");
$updcst->bind_param('di',$upcst,$upidcst);
$updload=$mysqli->prepare("UPDATE assortment SET download=? WHERE id=?");
$updload->bind_param('ii',$uprash,$upidrash);
//select assortment-------------------------------
$mysqli->query("SET NAMES 'utf8'");
if(isset($idcostassort) && $idcostassort==="YES") {
$mysqli->query("SET NAMES 'utf8'");
if($selallassort=$mysqli->prepare("SELECT id,title,cost,download FROM assortment WHERE id>1")) {
$selallassort->execute(); 
$selallassort->bind_result($idassort,$titleassort,$cstassort,$loadassort); 
while($selallassort->fetch()){
$allassort[$idassort]=$titleassort;$assortcost[$idassort]=$cstassort;$assortload[$idassort]=$loadassort;
} if(isset($selallassort)) $selallassort->close();}
}
}
//Выборка данных разделов*********************************
$mysqli->query("SET NAMES 'utf8'");
if(isset($idfirst) && $idfirst==="YES") {if($res=$mysqli->query("SELECT * FROM $parttable")) while($menupt=$res->fetch_assoc()){if(isset($menupt["id"])) $forcontent=$menupt["id"];$menupart[$forcontent]=$menupt["title"];}if(isset($res)) $res->close();if(isset($forcontent)) unset($forcontent);}
if(isset($menupart)) foreach($menupart as $k=>$v) if(isset($menuchapter)) if(isset($menuchapter[$k])) $numberpart[$k]=$v;//Получили те разделы, где есть главы
$mysqli->query("SET NAMES 'utf8'");
//Главы разделов*********************************
/*if(isset($idsnd) && $idsnd==="YES") {if(isset($menupart)) 
{if($resu=$mysqli->prepare("SELECT id,title FROM $chaptertable WHERE idpart=?"))
foreach($menupart as $k=>$v)
{$resu->bind_param('i',$k); 
$resu->execute(); 
$resu->bind_result($idchapt,$titchapt); 
while($resu->fetch()){$menuchapter[$idchapt]=$titchapt;}} if(isset($resu)) $resu->close();}*/
//Все статьи********************
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){if($resulting=$mysqli->query("SELECT id,title,idpart,idchapter,list FROM $maintable WHERE id>1 ORDER BY list")) while($menuarticle=$resulting->fetch_assoc()) {
if(isset($menuarticle["id"])) $forcontent=$menuarticle["id"];$forpart=$menuarticle["idpart"];$forchapter=$menuarticle["idchapter"];$forlist=$menuarticle["list"];
$menutitun[$forcontent]=$menuarticle["title"];
$titlelist[$forlist]=$menuarticle["title"];
$arraylist[$forcontent]=$forlist;
if($forpart!=="0") $idofpart[$forcontent]=$forpart;
//if($forchapter!=="0") $idofchapter[$forcontent]=$forchapter;
} 
if(isset($resulting)) $resulting->close();if(isset($forcontent)) unset($forcontent);if(isset($forpart)) unset($forpart);//if(isset($forchapter)) unset($forchapter);
if(isset($forlist)) unset($forlist);}
//Статьи всех разделов*************
if(isset($menupart) && isset($menutitun)) $articleofpart=array_intersect($menutitun,$menupart);
//Все разделы
//Статьи всех глав**********************
//if(isset($menuchapter) && isset($menupart)) $keypartchapter=array_intersect($menupart,$menuchapter);//var_dump($keypartchapter);//Разделы с главами
//if(isset($keypartchapter) && isset($menutitun)) $articleofchapt=array_intersect($menutitun,$keypartchapter);

// статьи разделов********************
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selsimplemenu=$mysqli->prepare("SELECT id,title FROM $maintable WHERE id>1 AND idpart>0 AND idchapter=0  ORDER BY list ")) {
$selsimplemenu->execute(); 
$selsimplemenu->bind_result($idsimple,$titlesimple); 
while($selsimplemenu->fetch()){
$menutit[$idsimple]=$titlesimple;
} if(isset($selsimplemenu)) $selsimplemenu->close();}
}
//Если таковой номер раздела имеется  - вложенные в раздел статьи
if(isset($numberpart)) {$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) if(isset($idartic) && $idartic==="YES"){
if($selmenupart=$mysqli->prepare("SELECT id,title,list FROM $maintable WHERE id>1 AND idpart='$numberpart' AND idchapter=0  ORDER BY list")) {
$selmenupart->execute(); 
$selmenupart->bind_result($idpt,$titlekeypt,$listpt); 
while($selmenupart->fetch()){
$menutitlepart[$idpt]=$titlekeypt;$menulistpart[$idpt]=$listpt;
} if(isset($selmenupart)) $selmenupart->close();}
}
}
//Организация контента
if(isset($numberpart) && $numberpart!==0) {if(isset($picker)) {
if(isset($menupart)) {$namepart=$menupart[$numberpart];$newneed=array_search($namepart,$titlelist);
} 
$mysqli->query("SET NAMES 'utf8'");
if(isset($maintable)) {foreach($picker as $key=>$value) { 
$plus=($key*10)+$value; 
$bdidpart=$numberpart;
$listforchange=$newneed+$plus;
$bdlistart=$listforchange;$bdidarticle=$value;
$insertpart->execute();
} 
}if(isset($insertpart)) $insertpart->close(); 
}
}
if(isset($simplearticle)) {
//Ключевую раздела сделать простой - выбранную статью или статьи - добавить 0 и удалить из разделов, статьи раздела исчезнут, статьи раздела тоже можно сделать простыми
if(isset($picker)) {foreach($picker as $key=>$value)
//Определяем тип статьи по id статьи
if(isset($menupart))//Удалить из разделов
{if(isset($menutitun) && isset($menutitun[$value])) $namepart=$menutitun[$value];if(isset($namepart)) $numbpart=array_search($namepart,$menupart);$query="DELETE FROM $parttable WHERE id=$numbpart";$resultpick=$mysqli->query($query);if($resultpick==true) header("Location:avpult.php?unit=$unit");
} 
if(isset($value)) {$upspartclsimpl=0;$upidartclsimpl=$value;}if($updarticlesimple->execute())
if(isset($updarticlesimple)) $updarticlesimple->close();header("Location:avpult.php?unit=$unit");
}
}
//Сделать ключевой
if(isset($klarticle)) {
if(isset($picker)) {foreach($picker as $key=>$value) {if(isset($menutitun) && isset($menutitun[$value])) $namepart=$menutitun[$value];$nmn=$namepart;if($insertrazd->execute()) {$upspartclsimpl=0;$upidartclsimpl=$value;$updarticlesimple->execute();
//
}}if(isset($updarticlesimple)) $updarticlesimple->close();
if(isset($insertrazd)) $insertrazd->close(); header("Location:avpult.php?unit=$unit");
}
}
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!ПЕРЕИМЕНОВАТЬ РАЗДЕЛ
$mysqli->query("SET NAMES 'utf8'");
if(isset($replpart)){if(isset($numberpart)){$mqrazdel=$part;$mqoldrazdel=$numberpart;$strazdel->execute();if(isset($numberpart)) {if(isset($menupart)) {$nameold=$menupart[$numberpart];if(array_search($nameold,$menutitun)==true) {$titl=$part;$titid=array_search($nameold,$menutitun);$uptitlearticl->execute();}}
}
}if(isset($uptitlearticl)) $uptitlearticl->close();if(isset($strazdel)) $strazdel->close();header("Location:avpult.php?unit=$unit");
}}

if(isset($save)) {
if(isset($redactor)) switch($redactor) {
case 0://Новая статья
//Раздел равен 0 idpart=0, иначе - проверяем совпадение с именем статьи, проверяем наличие раздела
$today=date("Y-m-d");
if($part===$title) {if(isset($menupart)) if(array_search($part,$menupart)) die();
else {$nmn=$part;$thisidpart=0;

}} else
{if(isset($menupart)) {if(array_search($part,$menupart)) $thisidpart=array_search($part,$menupart);else $thisidpart="0";} else $thisidpart="0";}

$mysqli->query("SET NAMES 'utf8'");
$tit=$title;$mss=$mess;$avt=$author;$dt=$today;$kw=$keywords;$antc=$annot;$idrz=$thisidpart;$newidgl=0;
if(isset($nmn)) $insertrazd->execute();
if($insertarticl->execute())
{$lastst=$mysqli->insert_id;$newlast1=$lastst*10000;
$upspartcl=$newlast1;$upidartcl=$lastst;}
if($updarticle->execute())
{if(isset($unit) && $unit==="payware") { if(isset($menupart)) { if(!array_search($title,$menupart)) {$idass=$lastst;$titass=$title;if(isset($costprod)) $cst=$costprod; else $cst=0;
$insertass->execute();}} else {$idass=$lastst;$titass=$title;if(isset($costprod)) $cst=$costprod; else $cst=0;
$insertass->execute();}
if(isset($insertass)) $insertass->close();}
if(isset($unit) && $unit==="shop"  && isset($menupart) && !array_search($title,$menupart)) {$idass=$lastst;$titass=$title;if(isset($costprod)) $cst=$costprod; else $cst=0;$loadass=0;$insertass->execute();if(isset($insertass)) $insertass->close();}
if(isset($insertrazd)) $insertrazd->close();if(isset($insertarticl)) $insertarticl->close();if(isset($updarticle)) $updarticle->close();
header("Location:avpult.php?unit=$unit");
}
break;
case 1://Редактирование
if(isset($part) && $part!=="0") {if($part===$title) $thisidpart="0";else  {if(isset($menupart)) $thisidpart=array_search($part,$menupart);else $thisidpart="0";}} else $thisidpart="0";
$today=date("Y-m-d");
$mysqli->query("SET NAMES 'utf8'");
$tit=$title;$upspartcl=$listarticle;$mss=$mess;$avt=$author;$dt=$today;$kw=$keywords;$antc=$annot;$idrz=$thisidpart;$newidgl="0";$totid=$id;
if($upallarticl->execute())
{if(isset($unit) && $unit==="payware" && isset($menupart) && !array_search($title,$menupart)) {$upidass=$id;$upass=$title;$updass->execute();if(isset($updass)) $updass->close();}
if(isset($unit) && $unit==="shop" && isset($menupart) && !array_search($title,$menupart)) {$upidass=$id;$upass=$title;$updass->execute();if(isset($upidass)) $upidass->close();}
if(isset($upallarticl)) $upallarticl->close();header("Location:avpult.php?unit=$unit");
}
break;
}
 }
//Создание и редактирование
if(isset($go)) {
if(isset($namearticle) && $namearticle==="") //Нет статьи
{$redactor=0;$part="0";$id="";}
else {//id статьи
if(isset($menutitun)) if(array_search($namearticle,$menutitun)) echo $id=array_search($namearticle,$menutitun);else $id=1;if(isset($titlelist)) if(array_search($namearticle,$titlelist)) $listarticle=array_search($namearticle,$titlelist);else $listarticle=0;
//Проверка на раздел $keyarticle - id ключевой статьи
if(isset($articleofpart) && array_search($namearticle,$articleofpart)==true) $keyarticle=array_search($namearticle,$articleofpart);
if(isset($keyarticle)) $part=$namearticle; 
else {//$idofpart - Значение столбца idpart заданной статьи
if(isset($idofpart)) if(isset($idofpart[$id])) {
$idpt=$idofpart[$id]; 
if(isset($menupart) && isset($idpt)) $part=$menupart[$idpt];} 
else $part="0";}
$redactor=1;}
}
//DELEATE ARTICLE
if(isset($delst) && isset($id) && isset($part)) {
if($part===$title)//Удалить ключевую статью - исчезут все статьи раздела
{ echo $numbpart=array_search($part,$menupart);$query="DELETE FROM $parttable WHERE id=$numbpart";$resultpick=$mysqli->query($query);if($resultpick==true) header("Location:avpult.php?unit=$unit");}
//Удаление простой статьи или статьи раздела
{if(isset($id) && $id>1) {$query="DELETE FROM $maintable WHERE id=$id";$resultart=$mysqli->query($query);if($resultart==true) header("Location:avpult.php?unit=$unit");}
else die("<h3>Первую статью не удаляем!</h3><a href='avpult.php?unit=$unit'>Начать сначала</a>");
}
}
if(isset($unit) && $unit!=="common" && $unit!=="set") {
//Отображение----------------------------------
$mysqli->query("SET NAMES 'utf8'");
if(isset($id)) {if($selarticle=$mysqli->prepare("SELECT title, content,author,dat,keywords,annotation FROM $maintable WHERE id=? ORDER BY list ")) {
$selarticle->bind_param('i',$id); 
$selarticle->execute(); 
$selarticle->bind_result($titleart,$contentart,$authorart,$datart,$kwart,$annotart); 
while($selarticle->fetch()){
$titlear[$id]=$titleart;
$contentar[$id]=$contentart;
$authorar[$id]=$authorart;
$datar[$id]=$datart;
$kwar[$id]=$kwart;
$annotar[$id]=$annotart;
} if(isset($selarticle)) $selarticle->close();}
if(isset($unit) && $unit==="payware") {if($selcost=$mysqli->prepare("SELECT cost FROM passortment WHERE id=?")){$selcost->bind_param('i',$id);$selcost->execute();$selcost->bind_result($costart);while($selcost->fetch()){ $thiscost[$id]=$costart;} if(isset($selcost)) $selcost->close(); }
}
}
}
