<?php session_start();header("Content-Type: text/html; charset=utf-8");define ( 'BUGIT', true );
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(isset($_POST['proven'])) $_SESSION['proven']=addslashes(strip_tags(trim($_POST['proven'])));
if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
if(file_exists("../upr.php")) include_once "../upr.php";
if(file_exists("lib/library.php")) include_once "lib/library.php";
if(file_exists("lib/pclzip/pclzip.lib.php")) include_once "lib/pclzip/pclzip.lib.php";
if(file_exists("top.php")) require_once "top.php";
if(isset($unit)) if(file_exists("$unit/top.php")) include_once "$unit/top.php";
//Подключение логотипа
if(file_exists("../variables/logotype.php")) include_once "../variables/logotype.php";
//ПОДключаем шаблон
if (file_exists("template/admin/admin.php")) include_once "template/admin/admin.php";
////////////////////////////////////////////////////////////////////

