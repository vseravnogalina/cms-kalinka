<?php 
/**@package KALINKA @author Родионова Галина Евгеньевна https://unatka.ru * @copyright Copyright © 2013-2019 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.5
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(!defined('BUGIT')) exit ('Ошибка соединения');
//Запрет доступа
if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;} 

if(isset($unit) && isset($arrblock)) { ?>
<menu>
   <ul>
     <li>
       <a href="avpult.php?unit=<?php echo $unit; ?>"><?php echo $arrblock[$unit]; ?></a>
     </li>
      <br>
     <li>
       <a href="avpult.php?unit=<?php echo $unit; ?>&amp;<?php echo $unit; ?>=pick.php">Орга&shy;низо&shy;вать кон&shy;тент</a>
    </li>
     <br>
<?php if(isset($pos) && isset($pos[12]))
        if(file_exists("set/$pos[12].php")) { ?>
     <li>
       <a href="avpult.php?unit=set&amp;set=<?php echo $pos[12] ?>.php">Комментарии</a>
     </li>
<?php    }
   if(file_exists("$unit/extra.php")) {
?> <br>
     <li>
       <a href="avpult.php?unit=<?php echo $unit; ?>&amp;<?php echo $unit; ?>=extra.php">extra</a>
    </li>
<?php
         }
 ?>
   </ul>
</menu> 
<?php } ?>
