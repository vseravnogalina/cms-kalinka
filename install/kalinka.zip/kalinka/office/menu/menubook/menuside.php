<?php 
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if (!defined('BUGIT')) exit ('Ошибка соединения');
//Запрет доступа
if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}

?>
<ul id="menu">
<?php
echo '<li><a href="avpult.php?unit=book">Блог</a></li><br>';
echo '<li><a href="avpult.php?unit=book&amp;book=pick.php">Организация контента</a></li><br>';
if(isset($pos) && isset($pos[12]))
if (file_exists("set/$pos[12].php")) 
{echo '<li><a href="avpult.php?page=set&amp;set='.$pos[12].'.php">Комментарии</a></li>';}
?>
</ul>
