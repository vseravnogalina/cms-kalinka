<?php if (!defined('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<div id="nav"><ul>
<?php if(file_exists("common/"))  
{echo '<li><a href="avpult.php">Общее</a>';
echo '<ul>';
echo '<li><a href="avpult.php?unit=common&amp;common=formod.php">Модули</a></li><br>';
if(file_exists("common/formodadm.php"))  
echo '<li><a href="avpult.php?unit=common&amp;common=formodadm.php">Звенья</a></li><br>';
if(file_exists("common/templates.php"))  
echo '<li><a href="avpult.php?unit=common&amp;common=templates.php">Шаблоны</a></li><br>';
if(file_exists("common/mn.php"))  
echo '<li><a href="avpult.php?unit=common&amp;common=mn.php">Меню</a></li><br>';
echo '<li><a href="avpult.php?unit=common&amp;common=izo.php">Картинки</a></li><br>';
?>
<li><a href="avpult.php?unit=common&amp;common=docum.php">Документы</a></li><br>
<?php
if(file_exists("common/logot.php")) echo '<li><a href="avpult.php?unit=common&amp;common=logot.php">Логотип и название</a></li>';
?>
</ul></li>
<?php
 }
if(file_exists("book/")) {echo '<li><a href="avpult.php?unit=book">Блог</a>';
echo '<ul>';
echo '<li><a href="avpult.php?unit=book&amp;book=pick.php">Организовать контент</a></li>';echo '</ul>';echo '</li>';
}
if(file_exists("book1/")) {echo '<li><a href="avpult.php?unit=book1">Блог1</a>';
echo '<ul>';
echo '<li><a href="avpult.php?unit=book1&amp;book1=pick.php">Организовать контент</a></li>';echo '</ul>';echo '</li>';
}
if (file_exists("freeware/"))  
{
?>
<li><a href="avpult.php?unit=freeware">Скачивания</a>
<ul>
<li><a href="avpult.php?unit=freeware&amp;freeware=pick.php">Организовать контент</a></li><br>
 <li><a href="avpult.php?unit=freeware&amp;freeware=hranilishe.php">Загрузка файлов</a></li><br>
</ul></li>
<?php
}
if (file_exists("payware/"))  
{
?>
<li><a href="avpult.php?unit=payware">Платные продукты</a>
<ul>
<li><a href="avpult.php?unit=payware&amp;payware=pick.php">Организовать контент</a></li><br>
 <li><a href="avpult.php?unit=payware&amp;payware=hranilishe.php">Загрузка файлов</a></li><br>
<li><a href="avpult.php?unit=payware&amp;payware=korzinash.php">Компоненты </a></li><br>
<?php if(file_exists("kniga/")) { ?>
<li><a href="avpult.php?unit=kniga&amp;kniga=kniga.php">Книга учета</a></li>
<?php
} ?>
</ul></li>
<?php
}
if(file_exists("shop/"))  
{echo '<li><a href="avpult.php?unit=shop">Магазин</a>';
?>
<ul>
<li><a href="avpult.php?unit=shop&amp;shop=korzinash.php">Компоненты </a></li><br>
<?php if(file_exists("kniga/")) { ?>
<li><a href="avpult.php?unit=kniga&amp;kniga=kniga.php">Книга учета</a></li
<?php
} ?>
</ul></li>
<?php
}
?>
</ul></div>  
