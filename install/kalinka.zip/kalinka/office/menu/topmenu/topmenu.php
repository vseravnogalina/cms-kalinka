<?php if (!defined('BUGIT')) exit ('Ошибка соединения');if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2019 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.5
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<nav>
   <ul>
<?php if(file_exists("common/")) { ?>
        <li><a href="avpult.php">Общее</a>
           <ul>
               <li>
                 <a href="avpult.php?unit=common&amp;common=formod.php">Мо&shy;ду&shy;ли</a>
               </li>
      <br> 
<?php if(file_exists("common/templates.php")) { ?>  
        <li>
          <a href="avpult.php?unit=common&amp;common=templates.php">Шаб&shy;ло&shy;ны</a>
        </li>
     <br>
<?php }
if(file_exists("common/mn.php")) { ?> 
        <li>
          <a href="avpult.php?unit=common&amp;common=mn.php">Меню</a>
        </li>
     <br>
<?php } ?>
        <li>
          <a href="avpult.php?unit=common&amp;common=izo.php">Изобра&shy;жения</a>
        </li>
     <br>
        <li>
          <a href="avpult.php?unit=common&amp;common=docum.php">До&shy;кумен&shy;ты</a>
        </li>
     <br>
        <li>
          <a href="avpult.php?unit=common&amp;common=forextra.php">Допол&shy;не&shy;ния</a>
        </li>
     <br>
    </ul>
  </li>
<?php
 }
             if(isset($arrblock))
                 foreach($arrblock as $key=>$value) {
                                if(file_exists($key)) { 
                                      if($key!=="common") {  
         ?>
          <li>
            <a href="avpult.php?unit=<?php echo $key; ?>" title="<?php echo $value; ?>"><?php echo $value; ?> </a>
      <ul>
        <li>
           <a href="avpult.php?unit=<?php echo $key; ?>&amp;<?php echo $key; ?>=pick.php">Орга&shy;низо&shy;вать кон&shy;тент</a>
        </li>
   <?php if(file_exists("$key/extra.php")) { ?>
 <br>
          <li>
           <a href="avpult.php?unit=<?php echo $key; ?>&amp;<?php echo $key; ?>=extra.php">extra</a>
         </li>     
  <?php      }              
         ?>
           </ul></li> <?php
         }                
     }
 
 }

 ?>

  </ul>
</nav>  
