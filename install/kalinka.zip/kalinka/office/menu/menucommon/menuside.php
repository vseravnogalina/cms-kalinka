<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2017 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.0
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<menu>
   <ul>
     <li>
       <a href="avpult.php">Общее</a>
     </li>
<br>
      <li>
       <a href="avpult.php?unit=common&amp;common=formod.php">Моду<wbr>ли</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=templates.php">Шабло<wbr>ны</a>
     </li>
<br>
     <li>
      <a href="avpult.php?unit=common&amp;common=mn.php">Меню</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=izo.php">Изо<wbr>бра<wbr>же<wbr>ния</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=docum.php">Доку<wbr>мен<wbr>ты</a>
     </li>
<br>
     <!--<li>
       <a href="avpult.php?unit=common&amp;common=logot.php"> Логотип и название</a>
     </li>
<br>-->
      <li>
       <a href="avpult.php?unit=set">Наст<wbr>ройки и до<wbr>пол<wbr>ни<wbr>тель<wbr>ные функции модулей</a>
     </li>
<br>
   </ul>
</menu>
