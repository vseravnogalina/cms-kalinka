<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2019 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 1.0.4
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<menu>
   <ul>
     <li>
       <a href="avpult.php">Общее</a>
     </li>
<br>
      <li>
       <a href="avpult.php?unit=common&amp;common=formod.php">Моду&shy;ли</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=templates.php">Шабло&shy;ны</a>
     </li>
<br>
     <li>
      <a href="avpult.php?unit=common&amp;common=mn.php">Меню</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=izo.php">Изо&shy;бра&shy;же&shy;ния</a>
     </li>
<br>
     <li>
       <a href="avpult.php?unit=common&amp;common=docum.php">Доку&shy;мен&shy;ты</a>
     </li>
<br>        <li>
          <a href="avpult.php?unit=common&amp;common=forextra.php">Допол&shy;не&shy;ния</a>
        </li>
     <br>
 
      <li>
       <a href="avpult.php?unit=set">Наст&shy;ройки и до&shy;пол&shy;ни&shy;тель&shy;ные функции модулей</a>
     </li>
<br>
   </ul>
</menu>
