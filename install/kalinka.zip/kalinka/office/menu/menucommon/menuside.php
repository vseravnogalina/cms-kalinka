<?php if(!defined('BUGIT')) exit ( "Ошибка соединения" );if(empty($_SESSION['proven'])) {die("Доступ закрыт");exit;}
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
?>
<ul id="menu">
<li><a href="avpult.php">Общее</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=formod.php">Модули</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=templates.php">Шаблоны</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=mn.php">Меню</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=izo.php">Картинки</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=docum.php">Документы</a></li><br>
<li><a href="avpult.php?unit=common&amp;common=logot.php"> Логотип и название</a></li><br>
<li><a href="avpult.php?unit=set">Настройки и дополнительные функции модулей</a></li><br>
</ul>
