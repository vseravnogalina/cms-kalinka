<?php
if (!defined('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKAru * @author Chikuna http:// * email gala.anita@mail.ru
* @copyright Copyright © 2014, 2015 Chikuna (Родионова Галина Евгеньевна)
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3 **/
if(empty($_SESSION['gruppaupr'])) die( "Доступ закрыт");
//если существует директория
if (is_dir($papka))
{ //Формируем массив
$posledov=array();
//Обозначаем директорию
$dr=$papka;
//Убираем точки
$skip = array('.', '..');
//сканируем
$mdsh = scandir($dr);
foreach($mdsh as $shmod) {
if(!in_array($shmod, $skip)) $posledov[]=$shmod;
}
}
//Чистим
clearstatcache(); ?>
