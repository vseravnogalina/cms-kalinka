<?php if(!defined ('BUGIT')) exit ('Ошибка соединения');
/**@package KALINKA @author Родионова Галина Евгеньевна http(s)://unatka.ru * @copyright Copyright © 2013-2016 Родионова Галина Евгеньевна* email gala.anita@mail.ru @ version 0.9.2
* @license   http://www.gnu.org/licenses/gpl.html GNU GPLv3**/
if(isset($id)) { 
if(file_exists("images/book/$id/")) {
if(isset($pos) && isset($pos[14]))
{$flname="modul/$pos[14]/def.php";if (file_exists($flname))if (file_get_contents($flname)) include_once $flname;}clearstatcache();
} 
if(file_exists("video/book/$id/")) {
if(isset($pos) && isset($pos[17]))
{$flname="modul/$pos[17]/def.php";if (file_exists($flname))if (file_get_contents($flname)) include_once $flname;}clearstatcache();
} 
//include_once "common/slider.php";
//Если статья относится к ключевым статьям idpart=0
if(isset($menutitle[$id])) 
{
//И отображаем контент ключевой страницы раздела
if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {echo "<h1> $titlear[$id]</h1>";echo "<div id='content'>".$contentar[$id];echo "<p>";echo $authorar[$id]."</p>";echo "<p>".$datar[$id]."</p></div>";}}
//Когда статья не является ключевой 
else {//Если статья - вложенная статья раздела
if(isset($id) && isset($menutitlepart[$id])) { 
if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {
echo "<h1>$titlear[$id]</h1><h4>Раздел $menupart[$idpart]</h4><div id='content'>";echo $contentar[$id]."<br>";echo "<p>".$authorar[$id]."</p>";echo "<p>".$datar[$id];?></p></div><?php 
if(isset($pos[18])) {$flname="modul/$pos[18]/def.php";
if(file_exists($flname))
if(file_get_contents($flname)) include_once $flname;}
} } //Если статья - простая  статья
/*else
{if(isset($titlear) && isset($contentar) && isset($authorar) && isset($datar)) {echo "<h1>$titlear[$id]</h1><div id='content'>";echo $contentar[$id]."<br>";echo "<p>".$authorar[$id]."</p>";echo "<p>".$datar[$id]."</p></div>";}}*/
}
}



